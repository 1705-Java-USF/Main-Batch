/*
HOMEWORK ASSIGNMENT WEEK 2
*/

/*
                    2.0 SQL QUERIES
*/

----------------
-- 2.1 SELECT --
----------------

--Task � Select all records from the Employee table.
SELECT * FROM Employee;

--Task � Select all records from the Employee table where last name is King.
SELECT * FROM Employee
    WHERE lower(LastName) = 'king';
    
--Task � Select all records from the Employee table where first name is
--Andrew and REPORTSTO is NULL.
SELECT * FROM Employee
    WHERE lower(FirstName) = 'andrew'
        AND ReportsTo is null;
 
------------------       
-- 2.2 ORDER BY --
------------------

--Task � Select all albums in Album table and sort result set in
--descending order by title.
SELECT * FROM Album
    ORDER BY Title desc;
    
--Task � Select first name from Customer and sort result set in
--ascending order by city
SELECT FirstName FROM Customer
    ORDER BY City;

---------------------
-- 2.3 INSERT INTO --
---------------------

--Task � Insert two new records into Genre table
--For this task, I will demonstrate both methods of inserting data
INSERT INTO Genre
    (GenreID, Name)
        VALUES
    (26, 'Tango');

INSERT INTO Genre VALUES
    (27, 'Techno');
    
--Task � Insert two new records into Employee table
--As before, I will use two different methods
INSERT INTO Employee
    (EmployeeID, LastName, FirstName, Title, ReportsTo, BirthDate,
            HireDate, Address, City, State, Country, PostalCode,
            Phone, Fax, EMail)
        VALUES
    (9, 'Barker', 'Bob', 'Game Show Host', 1,
            To_Date('12-DEC-1923', 'dd-MON-yy'),
            To_Date('04-SEP-1972', 'dd-MON-yy'),
            '2900 W. Alameda Avenue, Suite 800',
            'Burbank', 'CA', 'USA', '91515',
            '1 (818) 295-2700', '1 (800) 579-5788',
            'tickets@ocatv.com');

INSERT INTO Employee VALUES
    (10, 'Giovinco', 'Sebastian', 'Forward', 1,
            to_date('26-JAN-1987', 'dd-MON-yy'),
            to_date('07-MAR-2015', 'dd-MON-yy'),
            '50 Bay St #500', 'Toronto', 'Ontario',
            'Canada', 'M5J 2L2', '+1 (416) 360-4625',
            '+1 (416) 263-5700', 'mscannell@torontofc.ca');
            
--Task � Insert two new records into Customer table
INSERT INTO Customer
    (CustomerID, FirstName, LastName, Company, Address, City,
            State, Country, PostalCode, Phone, Fax, EMail,
            SupportRepID)
        VALUES
    (60, 'Tom', 'Cruise', 'Cruise/Wagner Productions',
            '10250 Constellation Way Suite 11007',
            'Los Angeles', 'CA', 'USA', '90067',
            '1 (310) 449-3777', '1 (310) 854-8100',
            'tom@cruise.com', 5);
            
INSERT INTO Customer VALUES
    (61, 'Homer', 'Simpson', 'Springfield Nuclear Power Plant',
            '742 Evergreen Terrace', 'Springfield', 'XX',
            'USA', '12345', '1 (808) 555-1234', '1 (808) 555-4321',
            'chunkylover53@aol.com', 4);
            
----------------
-- 2.4 UPDATE --
----------------

--Task � Update Michael Mitchell in Customer table to Robert Walter
UPDATE Customer
    SET FirstName = 'Robert', LastName = 'Walter'
    WHERE FirstName = 'Aaron' AND LastName = 'Mitchell';
    
--Task � Update name of artist in the Artist table �Creedence Clearwater
--Revival� to �CCR�
UPDATE Artist
    SET Name = 'CCR'
    WHERE Name = 'Creedence Clearwater Revival';
 
--------------
-- 2.5 LIKE --
--------------

--Task � Select all invoices with a billing address like �T%�
SELECT * FROM Invoice
    WHERE BillingAddress LIKE 'T%';
    
-----------------
-- 2.6 BETWEEN --
-----------------

--Task � Select all invoices that have a total between 15 and 50
SELECT * FROM Invoice
    WHERE Total BETWEEN 15 AND 50;
    
--Task � Select all employees hired between 1st of June 2003 and
--1st of March 2004
SELECT * FROM Employee
    WHERE HireDate > To_Date('01-JUN-2003', 'dd-MON-yy')
    AND HireDate < To_Date('01-MAR-2004', 'dd-MON-yy');
    
----------------
-- 2.7 DELETE --
----------------

--Task � Delete a record in Customer table where the name is Robert Walter
--(There may be constraints that rely on this, find out how to resolve them).
DELETE FROM Customer
    WHERE FirstName = 'Robert' AND LastName = 'Walter';
    
-- The above code does not work because there is a Foreign Key in the
-- Invoice table that connects to this customer.

-- Alter the table by creating a cascading delete
ALTER TABLE Invoice DROP CONSTRAINT FK_InvoiceCustomerID;
ALTER TABLE InvoiceLine DROP CONSTRAINT FK_InvoiceLineInvoiceID;

ALTER TABLE Invoice ADD CONSTRAINT FK_InvoiceCustomerID
    FOREIGN KEY (CustomerID)
    REFERENCES Customer (CustomerID)
    ON DELETE CASCADE;
    
ALTER TABLE InvoiceLine ADD CONSTRAINT FK_InvoiceLineInvoiceID
    FOREIGN KEY (InvoiceID)
    REFERENCES Invoice (InvoiceID)
    ON DELETE CASCADE;
    
DELETE FROM Invoice
    WHERE EXISTS
    (SELECT * FROM Customer
    WHERE Invoice.CustomerID = Customer.CustomerID
        AND Customer.FirstName = 'Robert'
        AND Customer.LastName = 'Walter');
        
/*
                    3.0 SQL FUNCTIONS
*/

----------------------------------
-- 3.1 SYSTEM DEFINED FUNCTIONS --
----------------------------------

--Task � Create a function that returns the current time.
CREATE OR REPLACE FUNCTION CurrTime
RETURN VARCHAR2
IS
    
BEGIN
    RETURN To_Char(sysdate(), 'HH:MI A.M.');
    
END;

DECLARE
BEGIN
    DBMS_OUTPUT.PUT_LINE('The current time is ' ||
    CurrTime());
END;

--Task � create a function that returns the length of a mediatype
--from the mediatype table
CREATE OR REPLACE FUNCTION MediaLen(rec IN NUMBER)
RETURN NUMBER
IS
    LenOfRec NUMBER;
BEGIN
    SELECT LENGTH(Name) INTO LenOfRec FROM MediaType
        WHERE MediaTypeID = rec;
    RETURN LenOfRec;
END;

DECLARE
    RecNo NUMBER;
BEGIN
    RecNo := 3;
    DBMS_OUTPUT.PUT_LINE('The length of record ' || Recno
        || ' is ' || MediaLen(RecNo));
END;

--------------------------------------------
-- 3.2 SYSTEM DEFINED AGGREGATE FUNCTIONS --
--------------------------------------------

--Task � Create a function that returns the average total of all invoices
CREATE OR REPLACE FUNCTION AvgInvoice
RETURN NUMBER
IS
    AvgAmt NUMBER;
BEGIN
    SELECT AVG(Total) INTO AvgAmt FROM Invoice;
    RETURN AvgAmt;
END;

DECLARE
BEGIN
    DBMS_OUTPUT.PUT_LINE('The average invoice amount is $' ||
        ROUND(AvgInvoice(), 2));
END;

--Task � Create a function that returns the most expensive track
CREATE OR REPLACE FUNCTION MaxPriceTrack
RETURN Track.Name%TYPE
IS
    MaxTrack Track.Name%TYPE;
BEGIN
    SELECT DISTINCT Name INTO MaxTrack FROM Track
        WHERE UnitPrice = (SELECT MAX(UnitPrice) FROM Track);
    RETURN MaxTrack;
END;

DECLARE
BEGIN
    DBMS_OUTPUT.PUT_LINE('The most expensive track is ' || MaxPriceTrack);
END;

---------------------------------------
-- 3.3 USER DEFINED SCALAR FUNCTIONS --
---------------------------------------

--Task � Create a function that returns the average price of
--invoiceline items in the invoiceline table
CREATE OR REPLACE FUNCTION AvgInvPrice
RETURN NUMBER
IS
    AvgPrice NUMBER;
BEGIN
    SELECT AVG(UnitPrice) INTO AvgPrice FROM InvoiceLine;
    RETURN AvgPrice;
END;

DECLARE
BEGIN
    DBMS_OUTPUT.PUT_LINE('The average price is $' ||
        ROUND(AvgInvPrice(), 2));
END;

---------------------------------------------
-- 3.4 USER DEFINED TABLE VALUED FUNCTIONS --
---------------------------------------------

--Task � Create a function that returns all employees who
--are born after 1968.
CREATE OR REPLACE FUNCTION Get_Emps
    RETURN SYS_REFCURSOR
IS
    Emps SYS_REFCURSOR;
BEGIN
    OPEN Emps FOR
    SELECT FirstName, LastName
        FROM Employee
        WHERE BirthDate > to_date('31-DEC-1968','DD-MON-YYYY');
    RETURN Emps;
END;

DECLARE
    funcCursor SYS_REFCURSOR;
    fn Employee.FirstName%type;
    ln Employee.LastName%type;
BEGIN
    funcCursor := Get_Emps();
    LOOP
        FETCH funcCursor into fn, ln;
        EXIT WHEN funcCursor%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(fn || ' ' || ln);
    END LOOP;
END;

/*
                    4.0 STORED PROCEDURES
*/

--------------------------------
-- 4.1 BASIC STORED PROCEDURE --
--------------------------------

--Task � Create a stored procedure that selects the first and
--last names of all the employees.
CREATE OR REPLACE PROCEDURE empNames(nameCursor OUT SYS_REFCURSOR)
IS
BEGIN
    OPEN nameCursor FOR
    SELECT FirstName, LastName FROM Employee;
END;

DECLARE
    funcCursor SYS_REFCURSOR;
    fn Employee.FirstName%type;
    ln Employee.LastName%type;
BEGIN
    empNames(funcCursor);
    LOOP
        FETCH funcCursor into fn, ln;
        EXIT WHEN funcCursor%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(fn || ' ' || ln);
    END LOOP;
END;

-------------------------------------------
-- 4.2 STORED PROCEDURE INPUT PARAMETERS --
-------------------------------------------

--Task � Create a stored procedure that updates the personal
--information of an employee.
CREATE OR REPLACE PROCEDURE ChangeName (id IN Employee.EmployeeID%type,
        fn IN Employee.FirstName%type, ln IN Employee.LastName%type)
IS
BEGIN
    UPDATE Employee
        SET FirstName = fn, LastName = ln
        WHERE EmployeeID = id;
END;

DECLARE
    id Employee.EmployeeID%type;
    fn Employee.FirstName%type;
    ln Employee.LastName%type;
BEGIN
    id := 1;
    fn := 'Mickey';
    ln := 'Mouse';
    ChangeName(id, fn, ln);
END;

SELECT * FROM Employee WHERE EmployeeID = 1;

--Task � Create a stored procedure that returns the managers of an employee.
CREATE OR REPLACE PROCEDURE Boss (id IN Employee.EmployeeID%type,
        fn OUT Employee.FirstName%type, ln OUT Employee.LastName%type)
IS
BEGIN
    SELECT FirstName INTO fn FROM Employee
        WHERE EmployeeID = (
            SELECT ReportsTo FROM Employee
            WHERE EmployeeID = id);
    SELECT LastName INTO ln FROM Employee
        WHERE EmployeeID = (
            SELECT ReportsTo FROM Employee
            WHERE EmployeeID = id);
END;

DECLARE
    id Employee.EmployeeID%type;
    fn Employee.FirstName%type;
    ln Employee.LastName%type;
BEGIN
    id := 4;
    Boss(id, fn, ln);
    DBMS_OUTPUT.PUT_LINE(fn || ' ' || ln);
END;

--------------------------------------------
-- 4.3 STORED PROCEDURE OUTPUT PARAMETERS --
--------------------------------------------

--Task � Create a stored procedure that returns the name and
--company of a customer.
CREATE OR REPLACE PROCEDURE CustName (id IN Customer.CustomerID%type,
        fn OUT Customer.FirstName%type, ln OUT Customer.LastName%type,
        comp OUT Customer.Company%Type)
IS
BEGIN
    SELECT FirstName INTO fn FROM Customer
        WHERE CustomerID = id;
    SELECT LastName INTO ln FROM Customer
        WHERE CustomerID = id;
    SELECT Company INTO comp FROM Customer
        WHERE CustomerID = id;
END;

DECLARE
    id Customer.CustomerID%type;
    fn Customer.FirstName%type;
    ln Customer.LastName%type;
    comp Customer.Company%type;
BEGIN
    id := 5;
    CustName(id, fn, ln, comp);
    IF comp IS NULL THEN comp := 'No Company';
        END IF;
    DBMS_OUTPUT.PUT_LINE(fn || ' ' || ln || ', ' || comp);
END;

/*
                    5.0 TRANSACTIONS
*/

--Task � Create a transaction that given a invoiceId will delete
--that invoice.
CREATE OR REPLACE PROCEDURE DelInv(id IN Invoice.InvoiceID%type)
IS
BEGIN
    DELETE FROM Invoice
        WHERE InvoiceID = id;
END;

DECLARE
    id Invoice.InvoiceID%type;
BEGIN
    id := 7;
    DelInv(id);
END;

-- The instructions indicated that there might be an issue because of
-- foreign keys, but that was already taken care of in 2.7.

--Task � Create a transaction nested within a stored procedure that
--inserts a new record in the Customer table
CREATE OR REPLACE PROCEDURE NewCust(id IN Customer.CustomerID%type,
        fn IN Customer.FirstName%type, ln IN Customer.LastName%type,
        comp IN Customer.Company%type, addr IN Customer.Address%type,
        city IN Customer.City%type, st IN Customer.State%type,
        cn IN Customer.Country%type, zip IN Customer.PostalCode%type,
        ph IN Customer.Phone%type, fax IN Customer.Fax%type,
        email IN Customer.EMail%type, rep IN Customer.SupportRepID%type)
IS
BEGIN
    INSERT INTO Customer VALUES
        (id, fn, ln, comp, addr, city, st, cn, zip, ph, fax, email, rep);
    COMMIT;
END;

DECLARE
    id Customer.CustomerID%type;
    fn Customer.FirstName%type;
    ln Customer.LastName%type;
    comp Customer.Company%type;
    addr Customer.Address%type;
    city Customer.City%type;
    st Customer.State%type;
    cn Customer.Country%type;
    zip Customer.PostalCode%type;
    ph Customer.Phone%type;
    fax Customer.Fax%type;
    email Customer.EMail%type;
    rep Customer.SupportRepID%type;
BEGIN
    SELECT MAX(CustomerID) INTO id FROM Customer;
        id := id + 1;
    fn := 'Rumpel';
    ln := 'Stiltskin';
    comp := 'Grimm Bros.';
    addr := '123 Silly Ln.';
    city := 'Walla Walla';
    st := 'WA';
    cn := 'USA';
    zip := '12345';
    ph := '1 (800) 867-5309';
    fax := '1 (800) 555-1234';
    email := 'rumpel@stiltskin.com';
    rep := 4;
    
    NewCust(id, fn, ln, comp, addr, city, st, cn, zip, ph, fax, email, rep);
END;

/*
                    6.0 TRIGGERS
*/

-------------------
-- 6.1 AFTER/FOR --
-------------------

--Task - Create an after insert trigger on the employee table fired
--after a new record is inserted into the table.
CREATE OR REPLACE TRIGGER AftIns
AFTER INSERT
    ON Employee
        FOR EACH ROW
DECLARE
BEGIN
    DBMS_OUTPUT.PUT_LINE('Procedure triggered');
END;

DELETE FROM Employee WHERE EmployeeID = 9;

INSERT INTO Employee
    (EmployeeID, LastName, FirstName, Title, ReportsTo, BirthDate,
            HireDate, Address, City, State, Country, PostalCode,
            Phone, Fax, EMail)
        VALUES
    (9, 'Barker', 'Bob', 'Game Show Host', 1,
            To_Date('12-DEC-1923', 'dd-MON-yy'),
            To_Date('04-SEP-1972', 'dd-MON-yy'),
            '2900 W. Alameda Avenue, Suite 800',
            'Burbank', 'CA', 'USA', '91515',
            '1 (818) 295-2700', '1 (800) 579-5788',
            'tickets@ocatv.com');
            
--Task � Create an after update trigger on the album table that fires
--after a row is inserted in the table
CREATE OR REPLACE TRIGGER AftInsAlb
AFTER INSERT
    ON Album
    FOR EACH ROW
DECLARE
BEGIN
    DBMS_OUTPUT.PUT_LINE('Procedure triggered from Album table');
END;

INSERT INTO Album VALUES
    (348, 'Philip Glass Ensemble Unplugged', 275);
    
DELETE FROM Album WHERE AlbumID = 348;

--Task � Create an after delete trigger on the customer table that
--fires after a row is deleted from the table.
CREATE OR REPLACE TRIGGER DelRowCust
    AFTER DELETE
    ON Customer
    FOR EACH ROW
DECLARE
BEGIN
    DBMS_OUTPUT.PUT_LINE('A cusotmer has been deleted.');
END;

DELETE FROM Customer WHERE CustomerID = 62;

/*
                    7.0 JOINS
*/

---------------
-- 7.1 INNER --
---------------

--Task � Create an inner join that joins customers and orders and
--specifies the name of the customer and the invoiceId.
SELECT C.FirstName, C.LastName, I.InvoiceID FROM Customer C
    INNER JOIN Invoice I
    ON C.CustomerID = I.CustomerID
    ORDER BY C.LastName ASC, C.FirstName ASC, I.InvoiceID ASC;
    
---------------
-- 7.2 OUTER --
---------------

--Task � Create an outer join that joins the customer and invoice table,
--specifying the CustomerId, firstname, lastname, invoiceId, and total.
SELECT C.CustomerID, C.FirstName, C.LastName, I.InvoiceID, I.Total
    FROM Customer C FULL OUTER JOIN Invoice I
    ON C.CustomerID = I.CustomerID
    ORDER BY C.LastName ASC, C.FirstName ASC, I.Total DESC, I.InvoiceID ASC;
    
---------------
-- 7.3 RIGHT --
---------------

--Task � Create a right join that joins album and artist specifying
--artist name and title.
SELECT A.Title, R.Name FROM Album A RIGHT JOIN Artist R
    ON A.ArtistID = R.ArtistID
    ORDER BY R.Name ASC, A.Title ASC;
    
---------------
-- 7.4 CROSS --
---------------

--Task � Create a cross join that joins album and artist and sorts by
--artist name in ascending order.
SELECT A.Title, R.Name FROM Album A CROSS JOIN Artist R;

--------------
-- 7.5 SELF --
--------------

--Task � Perform a self-join on the employee table, joining on
--the reportsto column.
SELECT E.FirstName AS Emp_FirstName,
        E.LastName AS Emp_LastName,
        B.FirstName AS Sup_FirstName,
        B.LastName AS Sup_LastName
    FROM Employee E, Employee B
    WHERE E.ReportsTo = B.EmployeeID;