package com.revature.test;
import org.apache.log4j.Logger;

public class Logging {
	
 
	final static Logger logger = Logger.getLogger(Logging.class);

	
	 public static void logException() {
		 logger.error("ERROR -- EXCEPTION");
	 }
	
	public void successfulDBcall() {
		logger.info("INFO -- Sucessful database call");
	}
	
	public void logInsert() {
		logger.info("INFO -- An insert was submitted");
	}

	public void logUpdate() {
		logger.info("INFO -- An update was submitted");
	}
	
	// 404 errors, etc
	public void invalidPage(){
		logger.error("ERROR -- Invalid page request");
	}
	
}
