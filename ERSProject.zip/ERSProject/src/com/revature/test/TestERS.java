package com.revature.test;

import static org.junit.Assert.fail;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;



public class TestERS {
	
	final static Logger logger = Logger.getLogger(TestERS.class);

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		logger.info("===Before The Front Controller starts===\n");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		logger.info("Shutting down ........");
	}

	@Before
	public void setUp() throws Exception {
		System.out.println("Setting up .......");
		
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("Tearing down .......");
	}

	@Test
	public void nullOrEmpty() {
		fail("Do no submit null or empty values");
	}
	


}
