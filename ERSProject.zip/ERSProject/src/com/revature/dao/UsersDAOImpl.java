package com.revature.dao;

import static com.revature.util.CloseStreams.close;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.revature.main.Users;
import com.revature.test.Logging;
import com.revature.util.ConnectionUtil;

public class UsersDAOImpl implements UsersDAO {
	Logging log = new Logging();
	@Override
	public void createUsers(Users u) {
		PreparedStatement pstmt = null;

		try (Connection conn = ConnectionUtil.getConnection();) {

			// This prepared statement will insert a reimbursement into the db.
			String sql = "INSERT INTO ers_users"
					+ "(user_id, username, user_password, firstname, lastname, email, user_role_id) VALUES"
					+ "(?,?,?,?,?,?,?)";

			pstmt = conn.prepareStatement(sql);

			pstmt.setNull(1, Types.INTEGER);
			pstmt.setString(2, u.getUsername());
			pstmt.setString(3, u.getPassword());
			pstmt.setString(4, u.getFirstname());
			pstmt.setString(5, u.getLastname());
			pstmt.setString(6, u.getEmail());
			pstmt.setInt(7, u.getRoleID());

			pstmt.executeQuery();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(pstmt);
		}

	}

	public Users selectUsersByUsername(String username) { // the manager likely
															// does not know the
															// id, so the
															// username
															// is the next best
															// option since it
															// is unique
		PreparedStatement ps = null;
		ResultSet rs = null;
		Users u = null;

		try (Connection conn = ConnectionUtil.getConnection();) {

			String sql = "SELECT * FROM ers_users WHERE username = ?";

			ps = conn.prepareStatement(sql);
			ps.setString(1, username);
			rs = ps.executeQuery();

			u = new Users();

			while (rs.next()) {
				u.setUserID(rs.getInt(1));
				u.setUsername(rs.getString(2));
				u.setPassword(rs.getString(3));
				u.setFirstname(rs.getString(4));
				u.setLastname(rs.getString(5));
				u.setEmail(rs.getString(6));
				u.setRoleID(rs.getInt(7));

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(ps);
			close(rs);
		}
		log.successfulDBcall();
		return u;

	}

	public HashMap<String, String> selectUsersByUsernameAndPassword(String username, String password) {
		// a map is returned due to key value pairs and the username must be
		// unique
		PreparedStatement ps = null;
		ResultSet rs = null;
		Users u = null;
		HashMap<String, String> hm = new HashMap<>();
		try (Connection conn = ConnectionUtil.getConnection();) {

			String sql = "SELECT firstname, lastname from ers_users WHERE username= ? AND user_password= ?";

			ps = conn.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, password);
			rs = ps.executeQuery();

			u = new Users();

			while (rs.next()) {

				u.setFirstname(rs.getString(1));
				u.setLastname(rs.getString(2));
				hm.put(rs.getString(1), rs.getString(2));

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(ps);
			close(rs);
		}
		log.successfulDBcall();
		return hm;

	}

	public List<Users> selectAllUsers() { // manager can view all employees

		PreparedStatement ps = null;
		ResultSet rs = null;
		Users u = null;
		ArrayList<Users> ral = new ArrayList<>();

		try (Connection conn = ConnectionUtil.getConnection();) {

			String sql = "SELECT * FROM ers_users";

			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();

			while (rs.next()) {
				u = new Users();
				u.setUserID(rs.getInt(1));
				u.setUsername(rs.getString(2));
				u.setPassword(rs.getString(3));
				u.setFirstname(rs.getString(4));
				u.setLastname(rs.getString(5));
				u.setEmail(rs.getString(6));
				u.setRoleID(rs.getInt(7));
				ral.add(u);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(ps);
			close(rs);
		}
		log.successfulDBcall();
		return ral;

	}

	public void deleteUserById(int id) {

	}

	public Users updateUser(Users u) { // Users can update their info

		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try (Connection conn = ConnectionUtil.getConnection();) {
			String sql = "UPDATE ers_users SET username= ?, user_password= ?, firstname= ?, lastname= ?, email= ?, user_role_id= ? WHERE user_id= ?";

			pstmt = conn.prepareStatement(sql);
			u.setUsername(u.getUsername());
			u.setPassword(u.getPassword());
			u.setFirstname(u.getFirstname());
			u.setLastname(u.getLastname());
			u.setEmail(u.getEmail());
			u.setRoleID(u.getRoleID());

			pstmt.setString(1, u.getUsername());
			pstmt.setString(2, u.getPassword());
			pstmt.setString(3, u.getFirstname());
			pstmt.setString(4, u.getLastname());
			pstmt.setString(5, u.getEmail());
			pstmt.setInt(6, u.getRoleID());
			pstmt.setInt(7, u.getUserID());

			pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(pstmt);
			close(rs);
		}
		log.successfulDBcall();
		return u;
	}

}
