package com.revature.dao;

/* This class is the combined result of multiple classes tied together by joins.
 * POJO setup with private instance variables and getter/setters for each
 */

public class Reuse {

	private int r_id;
	private String firstname;
	private String lastname;
	private double r_amount;
	private String r_description;
	private int r_status;
	private String r_submitted;
	private String status;

	public Reuse() {

	}

	public Reuse(String firstname, String lastname, String status) {

		this.firstname = firstname;
		this.lastname = lastname;
		this.status = status;
	}

	public Reuse(int r_id, String firstname, String lastname, double r_amount, String r_description, int r_status,
			String r_submitted, String status) {

		this.r_id = r_id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.r_amount = r_amount;
		this.r_description = r_description;
		this.r_status = r_status;
		this.r_submitted = r_submitted;
		this.status = status;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public double getr_amount() {
		return r_amount;
	}

	public void setr_amount(double r_amount) {
		this.r_amount = r_amount;
	}

	public String getr_description() {
		return r_description;
	}

	public void setr_description(String r_description) {
		this.r_description = r_description;
	}

	public String getr_submitted() {
		return r_submitted;
	}

	public void setr_submitted(String r_submitted) {
		this.r_submitted = r_submitted;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Reuse [r_id=" + r_id + ", firstname=" + firstname + ", lastname=" + lastname + ", r_amount=" + r_amount
				+ ", r_description=" + r_description + ", r_status=" + r_status + ", r_submitted=" + r_submitted
				+ ", status=" + status + "]";
	}

	public int getr_status() {
		return r_status;
	}

	public void setr_status(int r_status) {
		this.r_status = r_status;
	}

	public int getr_id() {
		return r_id;
	}

	public void setr_id(int r_id) {
		this.r_id = r_id;
	}

}
