package com.revature.dao;

import java.util.List;

import com.revature.main.Reimburse;

/*interface that the DAO Implementation needs to provide
 * Also the interface that the website uses for communicating with the database to retrieve info about reimbursements
 */
public interface ReimburseDAO {
	public Reimburse createReimbursement(Reimburse r);

	public Reimburse selectReimbursementById(int id);

	public List<Reimburse> selectReimbursement();

	public void deleteReimbursementById(int id);

}
