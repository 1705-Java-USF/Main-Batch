package com.revature.dao;

import java.util.HashMap;
import java.util.List;

import com.revature.main.Users;

/*interface that the DAO Implementation needs to provide
 * Also the interface that the website uses for communicating with the database to retrieve info about the users
 */
public interface UsersDAO {
	public void createUsers(Users u);
	public Users selectUsersByUsername(String username);
	public List<Users> selectAllUsers();
	public void deleteUserById(int id);
	public HashMap<String,String> selectUsersByUsernameAndPassword(String username, String password);
	public Users updateUser(Users u);
}
