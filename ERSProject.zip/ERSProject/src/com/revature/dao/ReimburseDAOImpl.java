package com.revature.dao;

import static com.revature.util.CloseStreams.close;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.revature.main.Reimburse;
import com.revature.test.Logging;
import com.revature.util.ConnectionUtil;

public class ReimburseDAOImpl implements ReimburseDAO {

	// creating timestamp for the date string
	private static final SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy K.mm.ss a");
	Logging log = new Logging();
	@Override
	public Reimburse createReimbursement(Reimburse r) {

		PreparedStatement pstmt = null;
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		String time = sdf.format(timestamp);

		r.setr_Submitted(time);
		r.setr_id(1);

		// prepared statement to insert a record into the database
		try (Connection conn = ConnectionUtil.getConnection();) { // get db
																	// connection

			String sql = "INSERT INTO ers_reimbursements"
					+ "(r_id, r_amount, r_description, r_receipt, r_submitted, r_resolved, user_id_author, user_id_resolver, rt_type, rs_status) VALUES"
					+ "(?,?,?,?,?,?,?,?,?,?)";

			pstmt = conn.prepareStatement(sql);
			pstmt.setNull(1, Types.INTEGER); // database automatically
												// increments (via stored
												// procedure)
			pstmt.setDouble(2, r.getr_Amount());
			pstmt.setString(3, r.getr_Description());
			pstmt.setString(4, r.getr_receipt());
			pstmt.setString(5, r.getr_submitted());
			pstmt.setString(6, r.getr_resolved());
			pstmt.setInt(7, r.getUserIdAuthor());
			pstmt.setNull(8, Types.INTEGER);

			pstmt.setInt(9, r.getr_type());
			pstmt.setInt(10, r.getr_status());
			pstmt.executeQuery();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(pstmt);
		}
		log.successfulDBcall();
		return r;
	}

	@Override
	public Reimburse selectReimbursementById(int id) { // select by id

		PreparedStatement ps = null;
		ResultSet rs = null;
		Reimburse r = null;

		try (Connection conn = ConnectionUtil.getConnection();) {

			String sql = "SELECT * FROM ers_reimbursements WHERE r_id = ?"; // managers
																			// can
																			// select
																			// reimbursements

			ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();

			r = new Reimburse();

			while (rs.next()) {
				r.setr_id(rs.getInt(1));
				r.setr_Amount(rs.getDouble(2));
				r.setr_Description(rs.getString(3));
				r.setr_Submitted(rs.getString(5));
				r.setr_resolved(rs.getString(6));
				r.setUserIdAuthor(rs.getInt(7));
				r.setUserIdResolver(rs.getInt(8));
				r.setr_type(rs.getInt(9));
				r.setr_status(rs.getInt(10));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(ps);
			close(rs);
		}
		log.successfulDBcall();
		return r;
	}

	@Override
	public List<Reimburse> selectReimbursement() { // all reimbursements can be
													// viewed

		PreparedStatement ps = null;
		ResultSet rs = null;
		Reimburse r = null;
		ArrayList<Reimburse> ral = new ArrayList<>();

		try (Connection conn = ConnectionUtil.getConnection();) {

			String sql = "SELECT * FROM ers_reimbursements";

			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();

			while (rs.next()) {
				r = new Reimburse();
				r.setr_id(rs.getInt(1));
				r.setr_Amount(rs.getDouble(2));
				r.setr_Description(rs.getString(3));
				r.setr_Submitted(rs.getString(5));
				r.setr_resolved(rs.getString(6));
				r.setUserIdAuthor(rs.getInt(7));
				r.setUserIdResolver(rs.getInt(8));
				r.setr_type(rs.getInt(9));
				r.setr_status(rs.getInt(10));
				ral.add(r);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(ps);
			close(rs);
		}
		log.successfulDBcall();
		return ral;
	}

	@Override
	public void deleteReimbursementById(int id) {

	}

}
