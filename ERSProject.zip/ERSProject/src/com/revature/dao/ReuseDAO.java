package com.revature.dao;

/* interface that the DAO Implementation needs to provide
 * Also the interface that the website uses for communicating with the database to retrieve info about data that 
 * is shared between two tables
 * 
 */
import java.util.List;

import com.revature.main.Reimburse;

public interface ReuseDAO {
	public List<Reuse> selectAllPending();
	public List<Reuse> selectAllResolved();
	public List<Reuse> resolvedBy();
	public Reuse updateReimbursement(Reuse r);
}
