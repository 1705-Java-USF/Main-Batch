package com.revature.dao;

import static com.revature.util.CloseStreams.close;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.revature.main.Reimburse;
import com.revature.main.Users;
import com.revature.test.Logging;
import com.revature.util.ConnectionUtil;

public class ReuseDAOImpl implements ReuseDAO {
	Logging log = new Logging();
	public List<Reuse> selectAllPending() {
		PreparedStatement ps = null;
		ResultSet rs = null;
		Reuse reu = null;
		ArrayList<Reuse> al = new ArrayList<>();

		try (Connection conn = ConnectionUtil.getConnection();) {

			// The join statement returns data from 3 different tables: the
			// reimbursements, users, and reimbursement status
			String sql = "SELECT ers_reimbursements.r_id, ers_users.firstname, ers_users.lastname, ers_reimbursements.r_amount, "
					+ "ers_reimbursements.r_description, ers_reimbursements.rs_status, "
					+ "TO_CHAR(ers_reimbursements.r_submitted, 'MM/DD/YYYY') \"SUBMITTED DATE\", "
					+ "ers_reimbursement_status.rs_status \"Status\" FROM ers_users INNER JOIN ers_reimbursements "
					+ "ON ers_users.user_id = ers_reimbursements.user_id_author INNER JOIN ers_reimbursement_status "
					+ "ON ers_reimbursements.rs_status = ers_reimbursement_status.rs_id WHERE ers_reimbursement_status.rs_status = 'Pending' ";

			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();

			while (rs.next()) {
				reu = new Reuse();
				reu.setr_id(rs.getInt(1));
				reu.setFirstname(rs.getString(2));
				reu.setLastname(rs.getString(3));
				reu.setr_amount(rs.getDouble(4));
				reu.setr_description(rs.getString(5));
				reu.setr_status(rs.getInt(6));
				reu.setr_submitted(rs.getString(7));
				reu.setStatus(rs.getString(8));

				al.add(reu);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(ps);
			close(rs);
		}

		log.successfulDBcall();
		return al;
	}

	public List<Reuse> selectAllResolved() {
		PreparedStatement ps = null;
		ResultSet rs = null;
		Reuse reu = null;
		ArrayList<Reuse> al = new ArrayList<>();

		try (Connection conn = ConnectionUtil.getConnection();) {

			// The join statement returns data from 3 different tables: the
			// reimbursements, users, and reimbursement status
			String sql = "SELECT ers_users.firstname, ers_users.lastname, ers_reimbursements.r_amount, "
					+ "ers_reimbursements.r_description, "
					+ "TO_CHAR(ers_reimbursements.r_submitted, 'MM/DD/YYYY') \"SUBMITTED DATE\", "
					+ "ers_reimbursement_status.rs_status \"Status\" FROM ers_users INNER JOIN ers_reimbursements "
					+ "ON ers_users.user_id = ers_reimbursements.user_id_author "
					+ "INNER JOIN ers_reimbursement_status ON ers_reimbursements.rs_status = ers_reimbursement_status.rs_id "
					+ "where ers_reimbursement_status.rs_status = 'Approved' or ers_reimbursement_status.rs_status = 'Denied' ";

			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();

			while (rs.next()) {

				reu = new Reuse();
				reu.setFirstname(rs.getString(1));
				reu.setLastname(rs.getString(2));
				reu.setr_amount(rs.getDouble(3));
				reu.setr_description(rs.getString(4));
				reu.setr_submitted(rs.getString(5));
				reu.setStatus(rs.getString(6));

				al.add(reu);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(ps);
			close(rs);
		}
		log.successfulDBcall();
		return al;

	}

	public List<Reuse> resolvedBy() {

		PreparedStatement ps = null;
		ResultSet rs = null;
		Reuse reu = null;
		ArrayList<Reuse> al = new ArrayList<>();

		try (Connection conn = ConnectionUtil.getConnection();) {
			// This statement returns the employee who requested the
			// reimbursement and the manager who resolved it
			// Multiple self joins were used on the reimbursements,
			// reimbursement status and users table to
			// obtain these results
			String sql = "SELECT b.firstname, b.lastname, d.rs_status FROM ers_users a,  ers_users b, ers_reimbursements c, ers_reimbursement_status d WHERE a.user_id = c.user_id_author and (c.rs_status =2 or c.rs_status=3) and b.user_id = c.user_id_resolver and c.rs_status= d.rs_id";

			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();

			while (rs.next()) {

				reu = new Reuse();
				reu.setFirstname(rs.getString(1));
				reu.setLastname(rs.getString(2));
				reu.setStatus(rs.getString(3));

				al.add(reu);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(ps);
			close(rs);
		}
		log.successfulDBcall();
		return al;

	}

	@Override
	public Reuse updateReimbursement(Reuse reu) {

		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try (Connection conn = ConnectionUtil.getConnection();) {
			String sql = "UPDATE ers_reimbursements SET rs_status = ? where r_id = ?";

			pstmt = conn.prepareStatement(sql);
			reu.setr_status(reu.getr_status());
			reu.setr_id(reu.getr_id());

			pstmt.setInt(1, reu.getr_status());
			pstmt.setInt(2, reu.getr_id());

			pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(pstmt);
			close(rs);
		}
		log.successfulDBcall();
		return reu;

	}

}
