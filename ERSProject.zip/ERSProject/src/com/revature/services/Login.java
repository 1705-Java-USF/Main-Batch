package com.revature.services;

import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;

import com.revature.dao.UsersDAO;
import com.revature.dao.UsersDAOImpl;

import com.revature.main.Users;
/* a helper class for validating  a user's login info and loading the user's db info after successful login
 * 
 */
public class Login {

	// test for valid user
	public boolean validateLogin(String username, String password) {

		HashMap<String, String> hm = new HashMap<>();
		UsersDAO dao = new UsersDAOImpl();
		//check username and password combo
		hm = dao.selectUsersByUsernameAndPassword(username, password);

		if (hm.isEmpty()) {	// if the map is empty, after the check, the username/password is invalid
			return false;
		} else {

			return true;	// user can login in 

		}
	}
	
	// this method loads the user's information for easy retrieval by the session object after login
	public Users getUser(String username){
		
		UsersDAO dao = new UsersDAOImpl();
		Users u = new Users();
		
		u = dao.selectUsersByUsername(username);
		
		return u;
	}

}
