package com.revature.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.revature.dao.UsersDAO;
import com.revature.dao.UsersDAOImpl;
import com.revature.main.Users;

/**
 * Servlet implementation class ViewServlet
 */
public class ViewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//int i=0;
		UsersDAO viewDAO=new UsersDAOImpl();
		//Users u = new Users();
		List<Users> ul= new ArrayList<>();
    	PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		ul=viewDAO.selectAllUsers();
		//Enumeration users=request.getParameterNames();
		out.println("<h1>All Users (Employees)</h1>");
		out.println("<table border='1px'><tr><th>id</th><th>username</th><th>password</th><th>firstname</th><th>lastname</th><th>email</th><th>role id</th></tr>");

		for(int i = 0; i < ul.size(); i++) {
			out.println("<tr><td>" + ul.get(i).getUserID() + "</td><td>" + ul.get(i).getUsername() + "</td><td>" 
			+ ul.get(i).getPassword() + "</td><td>" + ul.get(i).getFirstname() + "</td><td>" + ul.get(i).getLastname() 
			+"</td><td>" + ul.get(i).getEmail() + "</td><td>" + ul.get(i).getRoleID() + "</td></tr>");
		}

		out.println("</table>");			
		RequestDispatcher rd = request.getRequestDispatcher("UpdateServlet");
		rd.include(request, response);	
		
	}

}
