package com.revature.servlets;

import java.io.IOException;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.revature.dao.ReimburseDAOImpl;
import com.revature.dao.Reuse;
import com.revature.dao.ReuseDAOImpl;
import com.revature.dao.UsersDAOImpl;
import com.revature.main.Reimburse;
import com.revature.main.Users;
import com.revature.services.Login;
import com.revature.test.Logging;
import com.revature.test.TestERS;
/* The front controller acts as the main point of contact for the ERS website. It sends info the all he parts of the website
 * 
 */

public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	TestERS setup = new TestERS();	//tests for successful calls
	TestERS teardown = new TestERS(); //tests for successful completion of call
	Logging log = new Logging();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String url = request.getRequestURI();
		String[] tokens = url.split("/");
		String action = tokens[tokens.length - 1];
		action = action.substring(0, action.length() - 3).toLowerCase();
	
		RequestDispatcher rd = null;
		HttpSession session = null;
/*		try {
			TestERS.setUpBeforeClass();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			Logging.logException();
		}*/
		try {
			switch (action) {

			case "login":
				setup.setUp();
				request.setAttribute("issue", null);
				// grab username and password from form and store it
				String username = request.getParameter("username");
				String password = request.getParameter("password");
				Login vl = new Login();
				// if the login is valid, a session object is created
				if (vl.validateLogin(username, password)) {
					session = request.getSession();
					session.setAttribute("username", username);
					session.setAttribute("password", password);
					session.setAttribute("firstname", vl.getUser(username).getFirstname());
					session.setAttribute("lastname", vl.getUser(username).getLastname());
					session.setAttribute("email", vl.getUser(username).getEmail());
					session.setAttribute("roleid", vl.getUser(username).getRoleID());
					session.setAttribute("userid", vl.getUser(username).getUserID());

					// after the session object is loaded the "logged in" page
					// is loaded
					// base on user role
					if (vl.getUser(username).getRoleID() == 2) {
						rd = request.getRequestDispatcher("index.jsp"); // manager
																		// logged
																		// in
																		// page
					} else {
						rd = request.getRequestDispatcher("empindex.jsp"); // employee
																			// logged
																			// in
																			// page
					}
				} else {
					request.setAttribute("issue", "INVALID CRENDENTIALS!"); // if
																			// the
																			// login
																			// is
																			// invalid
				}
				// forward to respective pages when finished
				rd = request.getRequestDispatcher("index.jsp");
				rd.forward(request, response);
				teardown.tearDown();
				break;

			// The other cases are the result of an employee's actions
			case "logout":
				setup.setUp();
				request.getSession().invalidate();
				rd = request.getRequestDispatcher("index.jsp"); // after logout,
																// employee is
																// directed to
																// the login
																// screen
				rd.forward(request, response);
				teardown.tearDown();
				break;
			case "update":	// employee can update info
				setup.setUp();
				System.out.println("un: " + request.getSession().getAttribute("username"));
				update(request, response);
				teardown.tearDown();
				break;
			case "allpending":	// all pending requests are avaliable (for managers)
				setup.setUp();
				allPending(request, response);
				teardown.tearDown();
				break;
			case "allresolved":	// all resolved requests are available (for managers)
				setup.setUp();
				allResolved(request, response);
				teardown.tearDown();
				break;
			case "viewemployee": // an employee can view their info
				setup.setUp();
				viewEmployee(request, response); 
				teardown.tearDown();
				break;
			case "allemployees":	// a view of all employees (for managers)
				setup.setUp();
				allEmployees(request, response);
				teardown.tearDown();
				break;
			case "reimbursereq":
				setup.setUp();
				reimburseRequest(request, response);
				teardown.tearDown();
				break;
			default:
				response.sendError(404); // any invalid pages get the not found
				log.invalidPage();							// error
			}
		} catch (Exception e) {
			Logging.logException();
			e.printStackTrace();
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	// user info is updated
	protected void update(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {

		// the parameters for each needed value are connected to the form based
		// on parameter name
		String username = (String) request.getSession().getAttribute("username");
		String firstname = (String) request.getParameter("firstname");
		String lastname = (String) request.getParameter("lastname");
		String password = (String) request.getParameter("password");
		String email = (String) request.getParameter("email");
		int userid = (Integer) request.getSession().getAttribute("userid");
		int roleid = (Integer) request.getSession().getAttribute("roleid");

		// load the user
		Users u = new Users(userid, username, password, firstname, lastname, email, roleid);
		UsersDAOImpl update = new UsersDAOImpl();

		// update
		u = update.updateUser(u);

		RequestDispatcher rd;
		rd = request.getRequestDispatcher("update.jsp");
		rd.forward(request, response);
		log.logUpdate();

	}

	protected void allPending(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {

		// the intent was to have this method be able to print all pending
		// employees and
		// change their status, but the method does not work as intended. It
		// displays and can update
		// but does not do this based on the selected employee. It just updates
		// the next employee on the
		// list regardless of selection

		ReuseDAOImpl pending = new ReuseDAOImpl();
		List<Reuse> rl = new ArrayList<>();
		rl = pending.selectAllPending();
		ReuseDAOImpl updatePending = new ReuseDAOImpl();

		Reuse reu = new Reuse(rl.get(1).getr_id(), rl.get(2).getFirstname(), rl.get(3).getLastname(),
				rl.get(4).getr_amount(), rl.get(5).getr_description(), rl.get(6).getr_status(),
				rl.get(7).getr_description(), rl.get(8).getStatus());

		if (request.getParameter("status").equals("approved")) {
			// reu=updatePending.updateReimbursement(reu);
		}

		if (request.getParameter("status").equals("denied")) {
			int i;
			for (i = 0; i < rl.size(); i++) {
				new Reuse(rl.get(i).getr_id(), rl.get(i).getFirstname(), rl.get(i).getLastname(),
						rl.get(i).getr_amount(), rl.get(i).getr_description(), rl.get(i).getr_status(),
						rl.get(i).getr_description(), rl.get(i).getStatus());
			}

		}
		RequestDispatcher rd;
		rd = request.getRequestDispatcher("allpending.jsp");
		rd.forward(request, response);
	}

	protected void allResolved(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		// just a view 
		RequestDispatcher rd;
		rd = request.getRequestDispatcher("allresolved.jsp");
		rd.forward(request, response);

	}

	protected void viewEmployee(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		RequestDispatcher rd;
		rd = request.getRequestDispatcher("viewemployee.jsp");
		rd.forward(request, response);
	}

	protected void reimburseRequest(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {

		// employee can enter reimbursements, this is the implementation from the front 
		// controllers perspective
		int id = Integer.parseInt(request.getParameter("id"));
		id = 1;
		
		//these parameters are needed( with a form_) to communicate with the dao, which communicates 
		// with the db
		double amount = Double.parseDouble(request.getParameter("amount"));
		String description = (String) request.getParameter("description");
		String receipt = (String) request.getParameter("receipt");
		String submitted = (String) request.getParameter("submitted");
		String resolved = (String) request.getParameter("resolved");
		int authorid = Integer.parseInt(request.getParameter("authorid"));
		int resolverid = Integer.parseInt(request.getParameter("resolverid"));
		int rtype = Integer.parseInt(request.getParameter("rtype"));
		int rstatus = Integer.parseInt(request.getParameter("rstatus"));

		Reimburse r = new Reimburse(id, amount, description, receipt, submitted, resolved, authorid, resolverid, rtype,
				rstatus);
		ReimburseDAOImpl insert = new ReimburseDAOImpl();
		r = insert.createReimbursement(r);

		RequestDispatcher rd;
		rd = request.getRequestDispatcher("reimbursereq.jsp");
		rd.forward(request, response);
		log.logInsert();

	}

	protected void allEmployees(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {

		RequestDispatcher rd;
		rd = request.getRequestDispatcher("allemployees.jsp");
		rd.forward(request, response);

	}

}
