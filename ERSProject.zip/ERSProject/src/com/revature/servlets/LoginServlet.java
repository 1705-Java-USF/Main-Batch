package com.revature.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.revature.dao.UsersDAO;
import com.revature.dao.UsersDAOImpl;
import com.revature.main.Users;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		HashMap<String,String> hm=new HashMap<>(); 
		UsersDAO dao=new UsersDAOImpl();
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		Users u= new Users();
		hm=dao.selectUsersByUsernameAndPassword(username, password);
		u=dao.selectUsersByUsername(username);
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		if(hm.isEmpty()){
			out.println("<h3 style='color:red'>INCORRECT</h3>");
			RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
			rd.include(request, response);	
		}
		else {
			out.println("<h3 style='color:green'>CORRECT</h3>");
			//out.println("u email:" + u.getEmail());
			//out.println("u role id:" + u.getRoleID());
			//request.getAttribute(username);
			//out.println("Welcome" + username);
			 HttpSession session=request.getSession();  
            //session.setAttribute("username",username);  
           // session.setAttribute("password",password);
            

		}
		
		
		 // out.print("Username:<input type='text' name='email' value='"+u.getUsername()+"'/>"); 
		 // out.print("Email:<input type='email' name='email' value='"+u.getEmail()+"'/>");  
	}
	

	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
