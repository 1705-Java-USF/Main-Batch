package com.revature.main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.revature.dao.UsersDAO;
import com.revature.dao.UsersDAOImpl;
//Main class for testing User methods
public class UDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//UsersDAO dao7=new UsersDAOImpl();
		//Users u= new Users(29, "gatorade", "yt76piuy", "G", "Ade", "gator@ade.com",2);
		//dao7.updateUser(u);
		//System.out.println(u);
		
		
/*		List<Users> al= new ArrayList<>();
		UsersDAO dao8 = new UsersDAOImpl();
		al = dao8.selectAllUsers();
		for(int i = 0; i < al.size(); i++) {
			System.out.println("ul:" + al.get(i));

		}
		
		List<Object> ul= new ArrayList<>();
				
		UsersDAO dao3 = new UsersDAOImpl();
		//ul=dao3.selectAllPending();
		for(int i = 0; i < ul.size(); i++) {
			System.out.println("ul:" + ul.get(i).toString());

		}*/
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		//Users u = new Users();
		String username="sierra_m80";
		String password="poppy";
		HashMap<String,String> hm=new HashMap<>();
		
		
		//List<Users> ul= new ArrayList<>();
		//UsersDAO dao6=new UsersDAOImpl();
		//ul=dao6.selectAllUsers();
		//for(int i = 0; i < ul.size(); i++) {
		//	System.out.println("ul:" + ul.get(i).getUserID() + " " + ul.get(i).getUsername() + " " + ul.get(i).getPassword() 
		//			+ " " + ul.get(i).getFirstname() + " " + ul.get(i).getLastname() + " " + ul.get(i).getEmail() 
		//			+ " " + ul.get(i).getRoleID());
		//}
		
		
		
		
		
		

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		UsersDAO dao2 = new UsersDAOImpl();
		
		dao2.selectUsersByUsername("drpepper");
		
//29				Ade	gator@ade.com	2
	
		//int i=2;
		//UsersDAO dao = new UsersDAOImpl();
		
		
		
		//UsersDAO dao4 = new UsersDAOImpl();
		
		//Users u = new Users(null, "powerade", "powe32wfi", "Power", "Ade", "power@ade.com", 1);
		//dao.createUsers(u);
		
		
		
		//dao4.selectAllResolved();
		
		//UsersDAO dao5=new UsersDAOImpl();
		//hm=dao5.selectUsersByUsernameAndPassword(username, password);
		
		//for(Map.Entry<String,String> m:hm.entrySet()){  
		//	   System.out.println(hm.keySet() + " " +  hm.values());  
		//	  }  
		//
	}

}
