package com.revature.main;

public class Reimburse {

	private Integer r_id;
	private double r_amount;
	private String r_description;
	private String r_receipt;
	private String r_submitted;
	private String r_resolved;
	private int userIdAuthor;
	private Integer userIdResolver;
	private int r_type;
	private int r_status;

	public Reimburse() {

	}


	public Reimburse(double r_amount, String r_description) {
		super();
		this.r_amount = r_amount;
		this.r_description = r_description;
	}


	public Reimburse(Integer r_id, double r_amount, String r_description, String r_receipt, String r_submitted,
			String r_resolved, int userIdAuthor, Integer userIdResolver, int r_type, int r_status) {
		super();
		this.r_id = r_id;
		this.r_amount = r_amount;
		this.r_description = r_description;
		this.r_receipt = r_receipt;
		this.r_submitted = r_submitted;
		this.r_resolved = r_resolved;
		this.userIdAuthor = userIdAuthor;
		this.userIdResolver = userIdResolver;
		this.r_type = r_type;
		this.r_status = r_status;
	}

	public Integer getr_id() {
		return r_id;
	}

	public void setr_id(Integer r_id) {
		this.r_id = r_id;
	}

	public double getr_Amount() {
		return r_amount;
	}

	public void setr_Amount(double r_Amount) {
		this.r_amount = r_Amount;
	}

	public String getr_Description() {
		return r_description;
	}

	public void setr_Description(String r_description) {
		this.r_description = r_description;
	}

	public String getr_receipt() {
		return r_receipt;
	}

	public void setr_Receipt(String r_receipt) {
		this.r_receipt = r_receipt;
	}

	public String getr_submitted() {
		return r_submitted;
	}

	public void setr_Submitted(String r_submitted) {
		this.r_submitted = r_submitted;
	}

	public String getr_resolved() {
		return r_resolved;
	}

	public void setr_resolved(String r_resolved) {
		this.r_resolved = r_resolved;
	}

	public int getUserIdAuthor() {
		return userIdAuthor;
	}

	public void setUserIdAuthor(int userIdAuthor) {
		this.userIdAuthor = userIdAuthor;
	}

	public Integer getUserIdResolver() {
		return userIdResolver;
	}

	public void setUserIdResolver(Integer userIdResolver) {
		this.userIdResolver = userIdResolver;
	}

	public int getr_type() {
		return r_type;
	}

	public void setr_type(int r_type) {
		this.r_type = r_type;
	}

	public int getr_status() {
		return r_status;
	}

	public void setr_status(int r_status) {
		this.r_status = r_status;
	}
	
	@Override
	public String toString() {
		return "Query Results"+
						  "\n-------------------------------------------"+
						  "\nID:" + r_id + 
						  "\nAmount: "  + r_amount + 
						  "\nDescription: " + r_description + 
						  "\nReceipt: " + r_receipt + 
						  "\nSubmission date: " + r_submitted + 
						  "\nResolved date: " + r_resolved + 
						  "\nHandled by: " + userIdAuthor + 
						  "\nResolved by: " + userIdResolver + 
						  "\nReimbursement type: " + r_type + 
						  "\nReimbursement status: " + r_status + "";
	}

}
