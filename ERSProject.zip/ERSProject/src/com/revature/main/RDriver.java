package com.revature.main;

import java.util.List;

import com.revature.dao.ReimburseDAO;
import com.revature.dao.ReimburseDAOImpl;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

//Main class for testing Reimburse methods
public class RDriver {
	private static final SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy K.mm.ss a");

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		String s = sdf.format(timestamp);
		System.out.println(s);
		int id = 3;
		ReimburseDAO dao2 = new ReimburseDAOImpl();

		ReimburseDAO dao = new ReimburseDAOImpl();

		ReimburseDAO dao3 = new ReimburseDAOImpl();

		List<Reimburse> selectAll = dao3.selectReimbursement();

		Reimburse r = new Reimburse(null, 1.22, "test", null, null, null, 1, null, 1, 1);
		dao.createReimbursement(r);

		// dao2.selectReimbursementById(id);

	}

}
