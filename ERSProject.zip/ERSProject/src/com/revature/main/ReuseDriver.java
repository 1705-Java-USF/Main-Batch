package com.revature.main;

import java.util.ArrayList;
import java.util.List;

import com.revature.dao.Reuse;
import com.revature.dao.ReuseDAOImpl;

//Main class for testing Reuse methods
public class ReuseDriver {

	public static void main(String[] args) {
		/*
		 * ReuseDAOImpl dao= new ReuseDAOImpl(); List<Reuse> al= new
		 * ArrayList<>(); al=dao.selectAllPending(); for(int i = 0; i <
		 * al.size(); i++) { System.out.println("al:" + al.get(i));
		 * 
		 * } System.out.println("size: " + al.size());
		 */

		/*
		 * ReuseDAOImpl dao2 = new ReuseDAOImpl(); List<Reuse> al2 = new
		 * ArrayList<>(); al2 = dao2.selectAllResolved();
		 * 
		 * for (int i = 0; i < al2.size(); i++) { System.out.println("al2:" +
		 * al2.get(i));
		 * 
		 * }
		 */

		/*
		 * ReuseDAOImpl dao3 = new ReuseDAOImpl(); List<Reuse> al3 = new
		 * ArrayList<>(); al3 = dao3.resolvedBy(); for (int i = 0; i <
		 * al3.size(); i++) { System.out.println("al3:" + al3.get(i)); }
		 * 
		 * 
		 * System.out.println("size: " + al3.size());
		 */

		Reuse r = new Reuse(81,"Sierra", "Mist", 988.2, "test", 3,"06/22/2017", "Pending");
		ReuseDAOImpl dao4 = new ReuseDAOImpl();
		
		r=dao4.updateReimbursement(r);
		System.out.println("r:" + r);

	}

}
