package Servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DisplayPage
 */
public class DisplayPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisplayPage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String typed = request.getParameter("typed");
		String pass = request.getParameter("pass");
		String awesome = null;
			awesome = request.getParameter("awesome");
		String klondike = request.getParameter("klondike");
		String scale = request.getParameter("scale");
		
		response.setContentType("text/html");
				
		PrintWriter out = response.getWriter();
		
		out.println("<table border='1px'><tr><th>Header Name</th><th>Header Value</th></tr>");
		
		out.println("<tr><td>Typed:</td><td>" + typed + "</td></tr>");
		out.println("<tr><td>Password:</td><td>" + pass +
				" <-- Hah! Hope you weren't expecting security!</td></tr>");
		
		if (awesome != null) {
			awesome = "Of course you are!";
		} else {
			awesome = "You're not? Pfft...";
		}
		
		out.println("<tr><td>Are you awesome?</td><td>" + awesome + "</td></tr>");
		out.println("<tr><td>What would you do for a Klondike bar?</td><td>" + klondike + "</td></tr>");
		out.println("<tr><td>How awesome am I?</td><td>" + scale + " out of 10</td></tr>");
		
		out.println("</table>");
		
		out.println(
				"<hr>" +
				"<a href='index.html'>Home</a>"
			);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
