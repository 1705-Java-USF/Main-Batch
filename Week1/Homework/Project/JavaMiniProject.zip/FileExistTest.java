package MiniProject;

import static org.junit.Assert.assertTrue;

import java.io.File;

import org.junit.Before;
import org.junit.Test;

public class FileExistTest {
	
	// Instantiate the interface
	BankAccountIO testCase;
	
	// Set up the variables that will be needed
	String testFile;

	// This sets up the variables before the test begins
	@Before
	public void setUp() throws Exception {
		testCase = new BankAccountIO();
		testFile = "Accounts.txt";
	}
	
	// Test to make sure the file exists
	@Test
	public void fileExist() {
		File f = new File(testFile);
		assertTrue(f.exists());
	}
}
