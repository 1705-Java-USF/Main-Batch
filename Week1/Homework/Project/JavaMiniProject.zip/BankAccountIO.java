package MiniProject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Logger;

public class BankAccountIO {
	
	final static Logger logger = Logger.getLogger(BankAccountIO.class);

	public static void main(String[] args) {
		
		/*
		 * Declare the filename variable that will be used
		 * to store the accounts.
		 */
		String FilePath = "Accounts.txt";
		
		// Instantiate the write method
		BankAccountIO bank = new BankAccountIO();
		bank.accountWrite(FilePath);
		
		// Instantiate the read method
		bank.accountRead(FilePath);

	}
	/*
	 * This method will append accounts to the Accounts.txt file
	 */
	public void accountWrite(String filePath) {
		// Create new ArrayList to handle the three accounts to be input
		ArrayList<AccountConstruct> newAcct = new ArrayList<AccountConstruct>();
		
		// Create the scanner
		Scanner scan = new Scanner(System.in);
		
		// Create the variables for the inputs
		String fn, ln;
		double bal = 0.0D;
		boolean accept = false;
		String nString;
		
		// Instantiate an account
		BankAccountIO bank = new BankAccountIO();
		int x = bank.accountCounter(filePath);
		
		// The following for loop will get the account info from the user
		// and store it in the ArrayList
		for (int i = x + 1; i < x + 4; i++) {
			System.out.println("Please enter the first name:");
			fn = scan.nextLine();
			System.out.println("Please enter the last name:");
			ln = scan.nextLine();
			
			System.out.println("Please enter an account balance:");
			while (!accept) {
				try {
					nString = scan.nextLine();
					bal = Double.parseDouble(nString);
					accept = true;
				} catch (Exception e) {
					System.out.println("You must enter a number.");
					System.out.println("Please try again.");
					logger.info("An illegal input was made.");
				}
			}
			accept = false;
			
			newAcct.add(new AccountConstruct(i, fn, ln, bal));
		}
		
		scan.close();
		
		// The new accounts are then written into the text file.
		try {
			
			// Instantiate the BufferedWriter
			BufferedWriter bw = new BufferedWriter(new FileWriter(filePath, true));
			
			for (AccountConstruct i : newAcct) {
				bw.write('\n' + i.toString());
			}
			
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
			logger.error("The file was not found.");
		}
	}
	
	/*
	 * This method will read from the file and display the
	 * contents.  It uses a buffered reader to store the
	 * lines of code into a string.
	 */
	public void accountRead(String filePath) {
		// Create buffered reader for reading the file
		BufferedReader readFile;
		
		// Create a try/catch for reading from the file
		try {
			// Open the file for reading
			readFile = new BufferedReader(new FileReader(filePath));
			
			// Create a string for storing the data
			String account;
			
			// A while loop will cycle through the Accounts.txt file until it
			// reaches a blank line
			while ((account = readFile.readLine()) != null) {
					
				// Store the line into a string array, splitting whenever
				// a colon is seen
				String fields[] = account.split(":");
							
				// Print each account's info to the screen
				System.out.println("Account Number: " + fields[0]);
				System.out.println("Name: " + fields[1] + " " + fields[2]);
				System.out.println("Current Balance: $" + fields[3] + "\n");
			}
			
			readFile.close();
			
		} catch (Exception e) {
			System.out.println("The file " + filePath + " was not found.");
			logger.error("The file was not found.");
		}
		
	}
	
	/*
	 * This method will count the number of accounts in Accounts.txt
	 * and return the number as an integer.
	 */
	public int accountCounter(String filePath) {
		// Create buffered reader for reading the file
		BufferedReader readFile;
		
		// Create an int that will be returned
		int count = 0;
		
		try {
			readFile = new BufferedReader(new FileReader(filePath));
			
			// Create a loop that will increment for each line
			while (readFile.readLine() != null) {
				count++;
			}
			
			readFile.close();
			return count;
		} catch (Exception e) {
			System.out.println("The file " + filePath + " was not found.");
			return 0;
		}
		
	}

}
