package MiniProject;

import java.text.DecimalFormat;

public class AccountConstruct {

	/*
	 * Begin by declaring the variables that will be used
	 * for each account.  For simplicity, we will limit the
	 * variables to accountNumber, firstName, lastName, and
	 * accountBalance.  Typically, this record would have
	 * many more fields such as contact info, etc.
	 * 
	 * The variables are set to private and getters and
	 * setters will be used.  This is an essential feature
	 * of encapsulation and keeps personal data secure.
	 */
	private int accountNumber;
	private String firstName;
	private String lastName;
	private double accountBalance;
	
	/*
	 * The getters and setters of the private variables are
	 * created below.  These are used when the variable needs
	 * to be passed to the methods that call them.
	 */
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	
	/*
	 * The no-args constructor is defined below.  It will
	 * set a default value if a new account is created
	 * with no values inputed.  The default account number
	 * is -1 so that it forces the user to create a valid
	 * account number.
	 * 
	 * Ideally, it would create a unique account number but
	 * that is probably far beyond the scope of this project.
	 */
	public AccountConstruct () {
		this.accountNumber = -1;
		this.firstName = "FirstName";
		this.lastName = "LastName";
		this.accountBalance = 0.0D;
	}
	
	/*
	 * The constructor with arguments is defined below.  This
	 * will be used to define a new record when the fields
	 * have been defined.
	 */
	public AccountConstruct (int an, String fn, String ln, double ab) {
		this.accountNumber = an;
		this.firstName = fn;
		this.lastName = ln;
		this.accountBalance = ab;
	}
	
	/*
	 * The following creates a toString that will display the
	 * fields of the record in one long string, with each field
	 * separated by a colon.
	 */
	@Override
	public String toString() {
		DecimalFormat df = new DecimalFormat("0.00");
		return (accountNumber + ":" + firstName + ":" +
					lastName + ":" + df.format(accountBalance));
	}
	
}
