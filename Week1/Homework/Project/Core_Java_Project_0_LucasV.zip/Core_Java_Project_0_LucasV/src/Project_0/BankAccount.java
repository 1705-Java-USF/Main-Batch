//Lucas Vance
//Project 0
//Bank Account POJO
package Project_0;

public class BankAccount {
	
	//Create a BankAccount POJO with these variables
	private int bankAccountNumber; // -bankAccountNumber
	private String customerName; // -customerName
	private double balance; // -balance
	
	//Constructor for BankAccount, will use it for the write method
	public BankAccount(int bankAccountNumber, String customerName, double balance){
		this.bankAccountNumber = bankAccountNumber;
		this.customerName = customerName;
		this.balance = balance;
	}

	public int getBankAccountNumber() {
		return bankAccountNumber;
	}

	public String getCustomerName() {
		return customerName;
	}

	public double getBalance() {
		return balance;
	}

	

}
