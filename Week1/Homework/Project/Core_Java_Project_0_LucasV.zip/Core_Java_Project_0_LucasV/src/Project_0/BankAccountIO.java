//Lucas Vance
//Project 0
//Bank Account IO
package Project_0;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

//Main Class - BankAccountIO
public class BankAccountIO {

	final static Logger logger = Logger.getRootLogger();
	
	public static void main(String[] args) {
		
		//Create String FilePath
		String FilePath = "BankAccount.txt";
		
		//Create String FilePath2 for writing location
		String FilePath2 = "BankAccount2.txt";	
		
		logger.debug("Debug Message!");
		
		//Call read method
		try {
			BankAccountIO.readFromFile(FilePath);
			logger.debug("File read success!");
		} catch (IOException e) {
			logger.error("File not found!");
			e.printStackTrace();
		}
		
		//Call write method
		try {
			BankAccountIO.writeToFile(FilePath2);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public static void readFromFile(String FilePath) throws IOException{
		
		//Declare Buffered Reader
		BufferedReader br = null;
		
		//Declare File Reader
        FileReader fr = null;

        try {

        	//Create File Reader with designated File Path
            fr = new FileReader(FilePath);
            
            //Create Buffered Reader with designated File Reader
            br = new BufferedReader(fr);

            String currentLine;

    		// -Reads the objects from the file
            while ((currentLine = br.readLine()) != null) {
            	
            	//Parse every value separated by ":"
                String[] accountValues = currentLine.split(":");

                System.out.println("--Read content--");

                //Print Account Values
                System.out.println("Bank account number: "+accountValues[0]);
                System.out.println("Customer name: "+accountValues[1]);
                System.out.println("Bank account balance: "+accountValues[2]+"\n");

            }
            logger.trace("readFromFile() success!");

        } catch (IOException e) {
        	
        	logger.error("readFromFile() IOException");
            e.printStackTrace();

        } finally {

            try {
            	
            	//Close Buffered Reader
                if (br != null)
                    br.close();

                //Close File Reader
                if (fr != null)
                    fr.close();

            } catch (IOException ex) {

            	logger.error("readFromFile() not able to close file! IOException");
                ex.printStackTrace();

            }
        }
	}

	
	public static void writeToFile(String FilePath) throws IOException{

		// -Create 3 BankAccounts with properties initialized
		BankAccount ba1 = new BankAccount(1, "Lucas", 1234567.89);
		BankAccount ba2 = new BankAccount(2, "Bobbington", 555.55);
		BankAccount ba3 = new BankAccount(3, "Catberto", 975.31);
		
		// Create collection (array list)
		ArrayList<BankAccount> al = new ArrayList<BankAccount>();

		// -Store them in a Collection
		al.add(ba1); al.add(ba2); al.add(ba3);
		
		logger.trace("Array List has: " + al.size() + " Bank Account Objects!");
		
		// -BufferedWriter
		BufferedWriter bw = new BufferedWriter(new FileWriter(FilePath));
		
		// -Write the Objects to the file with any type of loop
		for(int i = 0; i < al.size(); i++){
			
			//Convert the bank account number (integer) to a string
			String temp1 = String.valueOf(al.get(i).getBankAccountNumber());
			//Write bank account number to file
			bw.write(temp1+":");
			
			//Write customer name (already a string)
			bw.write(al.get(i).getCustomerName()+":");

			//Convert balance (double) into a string
			String temp2 = String.valueOf(al.get(i).getBalance());
			//Write balance to file
			bw.write(temp2+"\n");

		}
		
		//Close buffered writer
		bw.close();
		
		logger.trace("writeToFile() success!");
	}
}
