package com.revature.hmwk1.question11.package1;

public class OneClass {

	// create float variables
	public float one;
	public float two;
	
	public OneClass(float a, float b) {
		this.one = a;
		this.two = b;
	}
}
