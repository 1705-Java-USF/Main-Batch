package com.revature.hmwk1.question18;

public abstract class ParentClass {

	// create 3 abstract methods
	abstract protected boolean hasUpperCase(String word);
	abstract protected String convertCase(String word);
	abstract protected void addTen(String num);
}
