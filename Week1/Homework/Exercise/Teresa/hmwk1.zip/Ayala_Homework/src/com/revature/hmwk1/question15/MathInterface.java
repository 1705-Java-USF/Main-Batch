package com.revature.hmwk1.question15;

public interface MathInterface {
	// an interface having the following methods: addition, subtraction, multiplication, and division
	
	public double addition(double a, double b);
	public double subtraction(double a, double b);
	public double multiplication(double a, double b);
	public double division(double a, double b);
	
}
