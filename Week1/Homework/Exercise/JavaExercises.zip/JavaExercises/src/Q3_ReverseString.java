import java.util.Scanner;

public class Q3_ReverseString {

	public static void main(String[] args) {

		// Declare input scanner
		Scanner scan = new Scanner(System.in);
		
		/*
		 * Get a string variable from the user, then
		 * call the method to reverse it.
		 */
		System.out.println("Enter a string to be reversed:");
		String toBeReversed = scan.nextLine();
		
		// Call the reversing method and change the input variable
		// to become its reversed string.
		Q3_ReverseString stringOut = new Q3_ReverseString();
		toBeReversed = stringOut.Reverso(toBeReversed);
		
		// Print result
		System.out.println(toBeReversed);
		
		// Close the scanner
		scan.close();

	}
	
	// This is the function that will reverse the string
	public String Reverso (String userEntered) {
		// Store length of initial string in a variable
		int len = userEntered.length();
		
		// This for loop appends the reversed string to the
		// original string
		for (int i = (len - 1); i >= 0; i--) {
			userEntered += userEntered.charAt(i); 
		}
		
		// This will remove the first half of the string,
		// leaving only the reversed string
		userEntered = userEntered.substring(len, 2*len);
		
		return userEntered;
	}

}
