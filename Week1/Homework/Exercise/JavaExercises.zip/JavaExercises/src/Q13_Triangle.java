
public class Q13_Triangle {

	public static void main(String[] args) {

		// Create a boolean variable that will determine whether a
		// 0 or 1 is displayed
		boolean display = false;
		
		// Main for loop.  Each iteration creates a row.
		for (int i = 1; i < 5; i++) {
			
			// Secondary for loop.  Will create each individual number.
			for (int j = 1; j <= i; j++) {
				
				// Determine whether to display a 0 or 1.  The number
				// alternates, so each time a 1 is written, the boolean
				// is set to false, and vice versa.
				if (display) {
					System.out.print("1 ");
					display = false;
				} else {
					System.out.print("0 ");
					display = true;
				}
			}
			System.out.print("\n");
		}

	}

}
