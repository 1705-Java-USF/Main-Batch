import java.util.ArrayList;

public class Q9_PrimeNumbers {
	
	public static void main(String[] args) {
		
		// Declare empty ArrayList to hold all of the primes
		ArrayList<Integer> primes = new ArrayList<Integer>();
		
		// Populate the ArrayList
		for (int i = 0; i < 100; i++) {
			primes.add(i+1);
		}
		
		// Declare the variables that will be used to test primality
		Q9_PrimeNumbers testPrime = new Q9_PrimeNumbers();
		boolean isItPrime;
		
		// Test each number for primality
		for (int i = 0; i < 100; i++) {
			isItPrime = testPrime.isPrime(primes.get(i));
			if (isItPrime) {
				System.out.println(primes.get(i));
			}
		}
		
	}
	
	public boolean isPrime (int p) {
		// Check if the number is 1 because 1 is not prime.
		if (p == 1) {
			return false;
		}
		
		// Find the square root of the input, rounded up.
		// This is because the test only needs to go as high as
		// the square root of the number.
		int sqrtp = (int)Math.sqrt(p) + 1;
		
		// Test for primality.  Return false if any number is
		// divisible
		for (int i = 2; i<sqrtp; i++) {
			if (p % i == 0) {
				return false;
			}
		}
		
		// Return true if the number never divided evenly,
		// meaning the number is prime.
		return true;
	}

}
