import java.util.Scanner;

public class Q18_MainProgram {

	public static void main(String[] args) {
		// Create an object of the subclass
		Q18_SubClass q18 = new Q18_SubClass();
		
		// Create a scanner
		Scanner scan = new Scanner(System.in);
		
		// Declare the input variable
		String s;
		
		// Ask for input
		System.out.println("Please input a string:");
		s = scan.nextLine();
		
		// Call the methods from the subclass
		System.out.println(q18.checkUpper(s));
		System.out.println(q18.convertLower(s));
		q18.convertInt(s);
		
		scan.close();

	}

}
