import java.io.BufferedReader;
import java.io.FileReader;

public class Q20_FileIO {
	
	public static void main(String[] args) {
		
		// Create buffered reader for reading the file
		BufferedReader readFile;
		try {
			// Open up the file for reading
			readFile = new BufferedReader(new FileReader("Data.txt"));
			
			// Create a string for storing the data
			String person;
			
			// A while loop will cycle through the Data.txt file until it
			// reaches a blank line
			while ((person = readFile.readLine()) != null) {
				
				// Store the line into a string array, splitting whenever
				// a colon is seen
				String fields[] = person.split(":");
				
				// Print each person's info to the screen
				System.out.println("Name: " + fields[0] + " " + fields[1]);
				System.out.println("Age: " + fields[2] + " years");
				System.out.println("State: " + fields[3] + " State\n");
				
			}
			
			// Close the file to prevent data leak
			readFile.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
