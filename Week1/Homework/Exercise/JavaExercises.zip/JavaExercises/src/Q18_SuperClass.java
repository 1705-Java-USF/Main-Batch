
abstract public class Q18_SuperClass {

	// Establish the abstract methods that will be inherited by the subclass
	abstract boolean checkUpper(String s);
	abstract String convertLower(String s);
	abstract void convertInt(String s);
	
}
