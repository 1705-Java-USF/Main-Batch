import java.util.ArrayList;

public class Q19_ArrayOddEven {
	
	public static void main(String[] args) {
		
		// Use ArrayList to declare a new array with the values 1 through 10
		ArrayList<Integer> intList = new ArrayList<Integer>(){{
			add(1);
			add(2);
			add(3);
			add(4);
			add(5);
			add(6);
			add(7);
			add(8);
			add(9);
			add(10);
		}};
		
		// This will create a variable to hold the value of the
		// sum of odds, then call the function to add the odd
		// numbers.  It then displays the result.
		Q19_ArrayOddEven odd = new Q19_ArrayOddEven();
		int sumOdd = odd.sumOfOdds(intList);
		System.out.println("The sum of the odd integers is " + sumOdd);
		
		// This will create a variable to hold the value of the
		// sum of evens, then call the function to add the even
		// numbers.  It then displays the result.
		Q19_ArrayOddEven even = new Q19_ArrayOddEven();
		int sumEven = even.sumOfEvens(intList);
		System.out.println("The sum of the even integers is: " + sumEven);
		
		// Display the non-prime numbers
		System.out.println("The following have the prime numbers removed:");
		Q19_ArrayOddEven prime = new Q19_ArrayOddEven();
		
		for (int i = 0; i < intList.size(); i++) {
			boolean isPrime = prime.isPrime(intList.get(i));
			if (isPrime == false){
				System.out.print(intList.get(i) + " ");
			}
		}
	}
	
	// This function adds the odd numbers
	public int sumOfOdds (ArrayList<Integer> a) {
		// Starting value of return value is zero
		int answer = 0;
		
		// The for loop cycles through the array and adds the
		// value if and only if it is odd (meaning value mod 2 = 1)
		for (int i = 0; i < a.size(); i++) {
			if (a.get(i) % 2 == 1) {
				answer += a.get(i);
			}
		}
		
		// Returns the result of adding the odd numbers
		return answer;
	}
	
	// This function adds the even numbers
	public int sumOfEvens (ArrayList<Integer> a) {
		int answer = 0;
		
		// Just like with the odd function, this adds the number from
		// the array if and only if the number is even
		for (int i = 0; i < a.size(); i++) {
			if (a.get(i) % 2 == 0) {
				answer += a.get(i);
			}
		}
		
		// Return the result of adding the even numbers
		return answer;
	}
	
	public boolean isPrime (int p) {
		// Check if the number is 1 because 1 is not prime.
		if (p == 1) {
			return false;
		}
		
		// Find the square root of the input, rounded up.
		// This is because the test only needs to go as high as
		// the square root of the number.
		int sqrtp = (int)Math.sqrt(p) + 1;
		
		// Test for primality.  Return false if any number is
		// divisible
		for (int i = 2; i<sqrtp; i++) {
			if (p % i == 0) {
				return false;
			}
		}
		
		// Return true if the number never divided evenly,
		// meaning the number is prime.
		return true;
	}

}
