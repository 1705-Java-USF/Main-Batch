import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Q14_Switch {

	public static void main(String[] args) {

		// Declare the variable for input
		int whichOne = 0;
		
		// Declare variable for determining if acceptable input
		// is entered
		boolean accept = false;
		
		// Initiate the scanner
		Scanner scan = new Scanner(System.in);
		
		// Ask for user input for which function to execute
		System.out.println("Please choose one of the following:");
		System.out.println("1: Find the square root of a number");
		System.out.println("2: Display today's date");
		System.out.println("3: Split a string into an array");

		// Wait for input then check if it is an integer
		while (!accept) {
			try {
				String nString = scan.nextLine();
				whichOne = Integer.parseInt(nString);
				
				// Throw an exception if the number is not one of the
				// correct choices.
				if (whichOne < 1 || whichOne > 3) {
					throw new Exception();
				}
				accept = true;
			} catch (Exception e) {
				System.out.println("You did not enter a valid number.");
				System.out.println("Please try again.");
			}
		}
		
		switch (whichOne) {
			// If the person chose 1, the switch will call a function
			// that takes the square root of a number
			case 1: Q14_Switch sqrt = new Q14_Switch();
					double answer;
					answer = sqrt.SqRt();
					System.out.println("The square root is " + answer);
					break;
					
			// If the person chooses 2, the switch will do a quick
			// sysout of the date
			case 2: DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
					Date date = new Date();
					System.out.println("Today's date is " + dateFormat.format(date));
					break;
			
			// This will split a string
			case 3: String toSplit = "I am learning Core Java";
					String[] words = toSplit.split("\\s");
					for(String w : words){  
						System.out.println(w);  
					}
					break;
					
			// The default should never be seen.  If it is, something
			// went wrong.
			default:
					System.out.println("There is a problem...");
					break;
		}
		
		scan.close();
		
	}
	
	public double SqRt () {
		// Declare variable for input
		double inputNumber = 0.0;
		
		// Declare boolean for the while statement
		boolean accept = false;
		
		System.out.println("Enter an number to be square rooted.");
		
		// Create a new scanner
		Scanner scanSqrt = new Scanner(System.in);
		
		while (!accept) {
			try {
				String nString = scanSqrt.nextLine();
				inputNumber = Double.parseDouble(nString);
				accept = true;
			} catch (Exception e) {
				System.out.println("You did not enter a valid number.");
				System.out.println("Please try again.");
			}
		}
		
		scanSqrt.close();
		
		return Math.sqrt(inputNumber);
	}

}
