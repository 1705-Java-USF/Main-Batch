
public class Q2_Fibonacci {

	public static void main(String[] args) {

		// Declare int array as a new variable
		int[] f = new int[25];
		int i;
		
		// The first two Fibonacci numbers are defined
		f[0] = 0;
		f[1] = 1;
		
		// Use a for loop to define the remaining Fibonacci numbers
		for (i = 2; i < 25; i++) {
			f[i] = f[i - 2] + f[i - 1];		// This adds the two
											// previous numbers for the
											// recursive function.
		}
		
		// Display the Fibonacci numbers
		for (i = 0; i < 25; i++) {
			System.out.println("f(" + i + ") = " + f[i]);
		}

	}

}
