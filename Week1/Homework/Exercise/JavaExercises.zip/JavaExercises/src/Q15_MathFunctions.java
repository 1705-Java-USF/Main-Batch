
public class Q15_MathFunctions implements Q15_MathInterface {

	// Call the add function of the interface
	@Override
	public double add(double x, double y) {
		
		return x + y;
		
	}

	// Call the subtract function of the interface
	@Override
	public double subtr(double x, double y) {

		return x - y;
		
	}

	// Call the multiplication function of the interface
	@Override
	public double mult(double x, double y) {

		return x * y;
		
	}

	// Call the division function of the interface
	@Override
	public double div(double x, double y) {

		return x / y;
		
	}
	
	

}
