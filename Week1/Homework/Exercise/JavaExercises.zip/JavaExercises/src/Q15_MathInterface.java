
public interface Q15_MathInterface {

	// Calculate the sum of two numbers
	public double add(double x, double y);
	
	// Calculate the difference of two numbers
	public double subtr(double x, double y);
	
	// Calculate the product of two numbers
	public double mult(double x, double y);
	
	// Calculate the quotient of two numbers
	public double div(double x, double y);
	
}
