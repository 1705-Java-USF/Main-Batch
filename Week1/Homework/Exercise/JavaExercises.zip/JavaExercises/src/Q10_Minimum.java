import java.util.Scanner;

public class Q10_Minimum {

	public static void main(String[] args) {

		// Declare two integers that will be used to hold the two
		// user inputed numbers
		int num1 = 0;
		int num2 = 0;
		
		// Create a boolean variable that will only return true when
		// an integer is imputted by the user.
		boolean accept = false;
		
		System.out.println("Enter the first number:");
		
		// Initiate the scanner
		Scanner scan = new Scanner(System.in);
		
		// Set up the input for the first number
		while (!accept) {
			try {
				String nString = scan.nextLine();
				num1 = Integer.parseInt(nString);
				accept = true;
			} catch (Exception e) {
				System.out.println("You must enter a number.");
				System.out.println("Please try again.");
			}
		}
		
		// Reset the accept variable for the next while loop
		accept = false;
		
		System.out.println("Enter the second number:");
		
		// Set up the input for the second number
		while (!accept) {
			try {
				String nString = scan.nextLine();
				num2 = Integer.parseInt(nString);
				accept = true;
			} catch (Exception e) {
				System.out.println("You must enter a number.");
				System.out.println("Please try again.");
			}
		}
		
		int minVal = (num1 < num2) ? num1 : num2;
		
		System.out.println("The minimum value is " + minVal);
		
		scan.close();
	}

}
