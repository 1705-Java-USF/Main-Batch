import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class Q15_MathTester {

	// Instantiate the interface
	Q15_MathFunctions testCase;
	
	// Declare the variables that will be used for testing
	double input1, input2;
	
	// This sets up the variables before the test begins
	@Before
	public void setUp() throws Exception {
		testCase = new Q15_MathFunctions();
		input1 = 12.0D;
		input2 = 4.0D;
		
	}
	
	// Test the addition method
	@Test
	public void testAdditionMethod() {
		assertEquals(16.0D, testCase.add(input1, input2), 0.001);
	}
	
	// Test the subtraction method
		@Test
		public void testSubtractionMethod() {
			assertEquals(8.0D, testCase.subtr(input1, input2), 0.001);
		}
		
	// Test the multiplication method
	@Test
	public void testMultiplicationMethod() {
		assertEquals(48.0D, testCase.mult(input1, input2), 0.001);
	}
		
	// Test the division method
	@Test
	public void testDivisionMethod() {
		assertEquals(3.0D, testCase.div(input1, input2), 0.001);
	}

}
