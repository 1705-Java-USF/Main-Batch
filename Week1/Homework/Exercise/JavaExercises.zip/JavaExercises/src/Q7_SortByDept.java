import java.util.Comparator;

public class Q7_SortByDept implements Comparator<Q7_Person> {

	// Used for sorting by the department
	public int compare(Q7_Person a, Q7_Person b)
	{
		return a.dept.compareTo(b.dept);
	}
	
}
