
public class Q1_Bubble {

	public static void main(String[] args) {
		
		// Numbers to be sorted are declared in an array
		int[] bub = {1,0,5,6,3,2,3,7,9,8,4};

		// Store the length of the array in a variable
		int len = bub.length;
		
		// Create a temporary variable for swapping
		int holder;
		
		for (int x = 0; x < (len - 1); x++) { // Main for loop
			
			for (int y = 0; y < (len - 1); y++) {	// Secondary for loop
				
				// The following if statement will swap the two
				// variables if they are in the wrong order
				if (bub[y] > bub[y+1]) {
					holder = bub[y];
					bub[y] = bub[y+1];
					bub[y+1] = holder;
				}
				
			}
			
		}
		
		// The following for loop will print the sorted array
		// to the console
		for (int i = 0; i < len; i++) {
			System.out.println(bub[i]);
		}
	}

}
