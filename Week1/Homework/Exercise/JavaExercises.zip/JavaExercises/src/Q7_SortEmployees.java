import java.util.ArrayList;
import java.util.Collections;

public class Q7_SortEmployees {

	public static void main(String[] args) {
		
		// Create the array list and populate it with employees.
		ArrayList<Q7_Person> emp = new ArrayList<Q7_Person>();
        emp.add(new Q7_Person("Tom", "Brady", 39, "Patriots"));
        emp.add(new Q7_Person("Jordy", "Nelson", 32, "Packers"));
        
        // Print the unsorted list
        System.out.println("=== UNSORTED ===");
        for (int i = 0; i < emp.size(); i++) {
        	System.out.println(emp.get(i));
        }
        
        // Sort by name then print the sorted list
        Collections.sort(emp, new Q7_SortByName());
        System.out.println("\n=== SORTED BY NAME ===");
        for (int i = 0; i < emp.size(); i++) {
        	System.out.println(emp.get(i));
        }
		
        // Sort by age then print the sorted list
        Collections.sort(emp, new Q7_SortByAge());
        System.out.println("\n=== SORTED BY AGE ===");
        for (int i = 0; i < emp.size(); i++) {
        	System.out.println(emp.get(i));
        }
        
     // Sort by department then print the sorted list
        Collections.sort(emp, new Q7_SortByDept());
        System.out.println("\n=== SORTED BY DEPARTMENT ===");
        for (int i = 0; i < emp.size(); i++) {
        	System.out.println(emp.get(i));
        }
		
	}
	
}
