import java.util.Comparator;

public class Q7_SortByAge implements Comparator<Q7_Person> {
	
	// Used for sorting by the age
	public int compare(Q7_Person a, Q7_Person b)
    {
		// This function will return a negative value if
		// b > a and a positive value if a > b
        return a.age - b.age;
    }

}
