
public class Q18_SubClass extends Q18_SuperClass {

	// This method will return true if there are any uppercase characters
	// in the string
	public boolean checkUpper (String s) {
		for (int i = 0; i < s.length(); i++) {
			if (Character.isUpperCase(s.charAt(i))) {
				return true;
			}
		}
		return false;
	}
	
	// The following will return a lower case equivalent of the string
	public String convertLower (String s) {
		return s.toLowerCase();
	}
	
	// If the input string is an integer, this will add ten to it and
	// output the result.  If the input string is not an integer, it
	// will generate an exception that, when caught, will display that
	// the method doesn't work.
	public void convertInt (String s) {
		try {
			Integer intString = Integer.parseInt(s) + 10;
			System.out.println(intString);
		} catch (Exception e) {
			System.out.println("This doesn't work for non-integer inputs.");
		}
	}
	
}
