public class Q16_StringArg {

	public static void main(String[] args) {

		// Print the first part of the line
		System.out.print("The number of characters in the argument is ");
		
		// Display length of string
		try {
			System.out.println(args[0].length());
		} catch (Exception e) {
			System.out.println("You did not enter any arguments.");
		}

	}

}
