import java.util.Scanner;

public class Q4_Factorial {

	public static void main(String[] args) {
		
		// Declare variables
		// n is the number we are taking the factorial of
		// answer is what will hold the answer of the factorial
		int n = 0;
		long answer;
		boolean accept = false;
		
		// Initiate the scanner
		Scanner scan = new Scanner(System.in);
		
		// Print message to screen
		System.out.println("Enter a number from 0 - 14");
		
		while (!accept) {
			try {
				String nString = scan.nextLine();
				n = Integer.parseInt(nString);
				accept = true;
			} catch (Exception e) {
				System.out.println("You can only take a factorial of a number.");
				System.out.println("Please try again.");
			}
		}
		
		// Creating an instance of the public int so that the function
		// can be called.
		Q4_Factorial factorial = new Q4_Factorial();
		answer = factorial.Factorial(n);
		
		// Print answer to the screen
		System.out.println(n + "! = " + answer);

		scan.close();
	}
	
	public long Factorial(int N) {
		
		// If the 
		if (N > 14) {
			System.out.println("Number too large.");
			return 0;
		}
		
		// Set the initial value of the factorial.  0! = 1, so we
		// set the initial value to 1.
		int fact = 1;
		
		// This for loop builds the function by multiplying all of
		// the numbers from 1 to N.  It is important to start from 1
		// and not 0 because if we multiply by zero, then the
		// function will return zero no matter what N equals.
		for (int i = 1; i < (N + 1); i++) {
			fact = fact * i;
		}
		return fact;
		
	}

}