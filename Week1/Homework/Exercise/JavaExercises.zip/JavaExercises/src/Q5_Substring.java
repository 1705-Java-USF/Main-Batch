import java.util.Scanner;

public class Q5_Substring {
	
	public static void main(String[] args) {
		
		// Declare all of the input variables
		String str;
		int idx = 0;
		boolean accept = false;
		
		// Initiate the scanner
		Scanner scan = new Scanner(System.in);
				
		// Print message to screen asking for string
		System.out.println("Enter a string of characters.");
		str = scan.nextLine();
		
		// Print message to screen asking for a number
		System.out.println("Enter the number of characters you want to return.");
				
		// The following while loop will only accept a number being entered
		while (!accept) {
			try {
				String idxString = scan.nextLine();
				idx = Integer.parseInt(idxString);
				accept = true;
			} catch (Exception e) {
				System.out.println("This must be a number.");
				System.out.println("Please try again.");
			}
		}
		
		// Call the method to shorten the string
		Q5_Substring subCaller = new Q5_Substring();
		String answerString = subCaller.shortString(str, idx);
		
		// Print the answer
		System.out.println(answerString);
		
		scan.close();
	}
	
	// This is the function that shortens the string
	public String shortString(String strIn, int countTo) {
		String strOut = "";		// This is an empty variable that
								// will be built upon
		
		char x;		// This will store each character of the
					// input string
		
		// This loo starts at zero and will end just before the
		// value of the idx variable is reached.
		for (int i = 0; i < countTo; i++) {
			x = strIn.charAt(i);	// Reads the character at the
									// correct position.
			
			strOut += x;		// Adds that character to the string
		}
		
		// Return the built string.
		return strOut;
	}

}
