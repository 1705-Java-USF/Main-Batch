import java.util.Scanner;

public class Q6_IsEven {

	public static void main(String[] args) {
		
		// Create an integer called testNum.  The program will determine if
		// testNum is odd or even.
		int testNum = 0;
		boolean result;
		boolean accept = false;
		
		// Initiate the scanner
		Scanner scan = new Scanner(System.in);
		
		// Print message to screen asking for a number
		System.out.println("Enter the number that you want to test.");
		
		// The following while loop will only accept an integer being entered
		while (!accept) {
			try {
				String idxString = scan.nextLine();
				testNum = Integer.parseInt(idxString);
				accept = true;
			} catch (Exception e) {
				System.out.println("This must be a number.");
				System.out.println("Please try again.");
			}
		}
		
		// Call the function to determine if testNum is even
		Q6_IsEven answer = new Q6_IsEven();
		result = answer.Evens(testNum);
		
		// Display result to the console
		if (result) {
			System.out.println("The number is even.");
		} else {
			System.out.println("The number is odd.");
		}
		
		scan.close();
	}
	
	public boolean Evens(int num) {
		
		// Create a temporary variable
		int divMult;
		
		// Since divMult is an integer, when the number is divided by two, if
		// the number is odd, the .5 at the end will be truncated, and therefore
		// it won't exactly equal the original variable when it is divided by two
		// then multiplied by two.
		divMult = num / 2 * 2;
		
		// If divMult equals the original number, then the original number must
		// have been even.  Otherwise, the original number must have been odd.
		if (divMult == num) {
			return true;
		} else {
			return false;
		}
		
	}

}
