import java.text.DecimalFormat;
import java.util.Scanner;

public class Q17_Interest {

	public static void main(String[] args) {
		
		// Declare variables.  Accept will be used to determine
		// whether an acceptable input has been entered
		double prin = 0.0D;
		double inter = 0.0D;
		double years = 0.0D;
		double amount = 0.0D;
		boolean accept = false;
		
		// Initiate the scanner
		Scanner scan = new Scanner(System.in);
		
		// Ask user for the principal
		System.out.println("Please enter the principal amount:");
		while (!accept) {
			try {
				String idxString = scan.nextLine();
				prin = Double.parseDouble(idxString);
				accept = true;
			} catch (Exception e) {
				System.out.println("This must be a number.");
				System.out.println("Please try again.");
			}
		}
		accept = false;
		
		// Ask user for the interest
		System.out.println("Please enter the percent interest rate:");
		while (!accept) {
			try {
				String idxString = scan.nextLine();
				inter = Double.parseDouble(idxString);
				accept = true;
			} catch (Exception e) {
				System.out.println("This must be a number.");
				System.out.println("Please try again.");
			}
		}
		accept = false;
		
		// Ask user for the number of years
		System.out.println("Please enter the number of years:");
		while (!accept) {
			try {
				String idxString = scan.nextLine();
				years = Double.parseDouble(idxString);
				accept = true;
			} catch (Exception e) {
				System.out.println("This must be a number.");
				System.out.println("Please try again.");
			}
		}
		
		// Call the method and display the final value
		Q17_Interest finalVal = new Q17_Interest();
		amount = finalVal.calcInt(prin, inter, years);
		
		// Display the answer
		DecimalFormat df = new DecimalFormat("0.00");
		System.out.println("The final value is $" + df.format(amount));

		scan.close();
	}
	
	public double calcInt (double p, double i, double y) {
		double finalValue = p * (i / 100) * y + p;
		
		return finalValue;
	}

}
