package Q11_Package;

public class Q11_FloatVariables {

	public float a = 5.42f;
	public float b = 13.6f;
	
}
