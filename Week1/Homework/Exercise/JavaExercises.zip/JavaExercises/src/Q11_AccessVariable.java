import Q11_Package.*;

public class Q11_AccessVariable {

	public static void main(String[] args) {
		
		Q11_FloatVariables printIt = new Q11_FloatVariables();
		
		float v1 = printIt.a;
		float v2 = printIt.b;
		
		System.out.println("The first variable is " + v1);
		System.out.println("The second variable is " + v2);

	}

}
