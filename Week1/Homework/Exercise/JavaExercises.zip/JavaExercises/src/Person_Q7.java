public class Person_Q7 implements Comparable<Person_Q7>{
	
	private String firstName;
	private String lastName;
	private String department;
	private int age;
	
	public Person_Q7 (String firstName, String lastName, String department, int age) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.department = department;
		this.age = age;
	}
	
	public String toString() {
		return "Name: " + lastName + ", " + firstName + " -- Department: " + department + " -- Age: " + age;
	}

	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public String getDepartment() {
		return department;
	}
	
	public void setDepartment(String department) {
		this.department = department;
	}
	
	public int getAge() {
		return age;
	}
	
	public void setAge(int age) {
		this.age = age;
	}
	
	@Override
	public int compareTo(Person_Q7 p) {
		return this.lastName.compareTo(p.lastName);
	}
	
}
