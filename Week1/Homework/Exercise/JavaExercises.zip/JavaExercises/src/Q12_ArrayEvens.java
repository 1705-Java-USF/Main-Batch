
public class Q12_ArrayEvens {

	public static void main(String[] args) {
		// Declare a new array of correct size
		int []arrayEvens = new int[100];
		
		// Populate the array with the values 1 through 100
		for (int i = 0; i < arrayEvens.length; i++) {
			arrayEvens[i] = i + 1;
		}
		
		// Use the enhanced for loop to print out only the evens
		for (int j : arrayEvens) {
			if (j % 2 == 0) {
				System.out.println(j);
			}
		}

	}

}
