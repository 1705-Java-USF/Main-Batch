import java.util.ArrayList;

public class Q8_ArrayPalindromes {

	public static void main(String[] args) {

		// Boolean variable that holds true or false depending
		// on whether the string is a palindrome.
		boolean isPal;
		
		// Declare empty ArrayLists that will be populated
		// with either palindromes or non-palindromes
		ArrayList<String> palList = new ArrayList<String>();
		ArrayList<String> noPalList = new ArrayList<String>();
		
		// Create the initial string array with the values
		// that will be stored
		String[] pal = {"karan", "madam", "tom",
				"civic", "radar", "sexes", "jimmy", "kayak",
				"john", "refer", "billy", "did"};
		
		// Create a variable for calling the palindrome tester.
		Q8_ArrayPalindromes palCaller = new Q8_ArrayPalindromes();
		
		// This for loop will proceed through the array and test each member
		// to see if it is a palindrome
		for (String x : pal) {
			isPal = palCaller.testPalindrome(x);		// Call tester
			
			//The following if statement will determine where to put the
			//string depending on where it is a palindrome.
			if (isPal) {
				palList.add(x);
			} else {
				noPalList.add(x);
			}
		}
		
		// Display the results
		System.out.println("The following words are palindromes:");
		System.out.println(palList);
		System.out.println("\nThe following are not palindromes:");
		System.out.println(noPalList);
		
	}
	
	// This is a boolean function that will test whether a string
	// is a palindrome.  It returns true if it is a palindrome
	// and it returns false if it is not.
	public boolean testPalindrome(String tester) {
		
		// Reverse the string
		String testAgainst = new StringBuilder(tester).reverse().toString();
		
		// Compare the original string to the reversed string
		if (tester.equals(testAgainst)) {
			return true;
		} else {
			return false;
		}
	}

}
