import java.util.Comparator;

public class Q7_SortByName implements Comparator<Q7_Person> {
	
	// Used for sorting by the last name
	public int compare(Q7_Person a, Q7_Person b)
    {
        return a.lName.compareTo(b.lName);
    }

}
