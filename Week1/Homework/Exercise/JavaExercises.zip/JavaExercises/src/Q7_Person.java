// This class represents the employee
public class Q7_Person {

	String fName;
	String lName;
	int age;
	String dept;
	
	// Constructor
	public Q7_Person(String fName, String lName, int age, String dept) {
		this.fName = fName;
		this.lName = lName;
		this.age = age;
		this.dept = dept;
	}
	
	// Used to generate the string that is returned to main
	public String toString() {
		return this.fName + " " + this.lName + ", " +
				dept + ", Age " + age;
	}
	
}
