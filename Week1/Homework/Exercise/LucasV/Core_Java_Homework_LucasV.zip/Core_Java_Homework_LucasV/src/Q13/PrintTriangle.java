//Lucas Vance
//Core Java Homework
//Question 13
//Print Triangle
package Q13;

import java.util.ArrayList;

public class PrintTriangle {

	public static void main(String[] args) {
		//Create Triangle with input number of lines
		PrintTriangle.triangleConstruct(4);
	}

	public static void triangleConstruct(int input1){
		//Create an array list to hold 0's and 1's
		ArrayList<String> al = new ArrayList<>();
		//Notice 0 1 0 1 0 pattern with \n's in between
		//For number of lines, (n*n+1)/2 numbers are printed
		//Each loop will add 2 numbers, divide n by 2 again
		for(int i = 0; i <= ((input1*(input1+1))/4); i++){
		al.add("0 ");
		al.add("1 ");
		}
		//Integer to keep track of index
		int count = 0;
		//Loop for n lines
		for(int i = 0; i < input1; i++){
			//Print amount of numbers depending on line number
			for (int x = 0; x <= i; x++){
				System.out.print(al.get(count));		
				count++;
			}
			System.out.println();
		}
	}
}
