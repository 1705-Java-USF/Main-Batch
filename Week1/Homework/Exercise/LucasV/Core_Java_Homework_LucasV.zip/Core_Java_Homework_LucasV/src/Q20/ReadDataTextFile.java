//Lucas Vance
//Core Java Homework
//Question 20
//Read text file and format
package Q20;

import java.io.File;
import java.util.Scanner;

public class ReadDataTextFile {
	public static void main(String[] args) throws Exception{
		//Get directory and save it to a string
	    String directory = System.getProperty("user.dir");
	    //Get file name and add it to string
	    String fileLocation = directory + "\\data.txt";
	    //Save file content into string
	    @SuppressWarnings("resource")
		String content = new Scanner(new File(fileLocation)).useDelimiter("\\Z").next();
	    //Split the string into string parts array delimited by new lines and :
		String[] parts = content.split("\\n|:");
		//Loop through string parts
		for(int x = 0; x < parts.length; x++){
			//Indexes divisible by 4 is the first name
			if(x%4==0){
				System.out.print("Name: " + parts[x]);
			}
			//Indexes with remainder 1 is the last name
			else if(x%4==1){
				System.out.print(" " + parts[x] + "\n");
			}
			//Indexes with remainder 2 is the age
			else if(x%4==2){
				System.out.println("Age: " + parts[x]);
			}
			//Indexes with remainder 3 is the state
			else if(x%4==3){
				System.out.println("State: " + parts[x]);
			}
		}
	}
}
