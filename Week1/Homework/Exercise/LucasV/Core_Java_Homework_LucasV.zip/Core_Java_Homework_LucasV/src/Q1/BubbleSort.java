//Lucas Vance
//Core Java Homework
//Question 1
//Bubble Sort
package Q1;

public class BubbleSort{

	public static void main(String[] args){
		//Create an unsorted array
		int anArray[] ={1,0,5,6,3,2,3,7,9,8,4};
        int tempValue = 0;  
        
        //Print the contents of the unsorted Array
        System.out.println("Unsorted Array: ");
        for(int z=0; z < anArray.length; z++){
       	 System.out.print(anArray[z] + " ");
        }
        
        for(int x=0; x < anArray.length; x++){  
        	for(int y=1; y < (anArray.length-x); y++){  
        		//compare adjacent elements
        		if(anArray[y-1] > anArray[y]){  
                //swap elements  
                tempValue = anArray[y-1];  
                anArray[y-1] = anArray[y];  
                anArray[y] = tempValue;  
                }
        	}
        }
        
        //Print the contents of the bubble sorted Array
        System.out.println("\nBubble Sorted Array: ");
        for(int z=0; z < anArray.length; z++){
        	System.out.print(anArray[z] + " ");
        }
         
	}

}