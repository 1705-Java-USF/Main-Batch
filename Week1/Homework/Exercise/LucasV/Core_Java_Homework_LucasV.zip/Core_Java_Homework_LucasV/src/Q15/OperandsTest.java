//Lucas Vance
//Core Java Homework
//Question 15
//Operands
package Q15;

public class OperandsTest {

	public static void main(String[] args) {
		//Create OperandsClass Object
		OperandsClass oc = new OperandsClass();
		//Call two methods using hard coded values
		System.out.println(oc.addition(5, 7));
		System.out.println(oc.multiplication(5, 7));
	}

}
