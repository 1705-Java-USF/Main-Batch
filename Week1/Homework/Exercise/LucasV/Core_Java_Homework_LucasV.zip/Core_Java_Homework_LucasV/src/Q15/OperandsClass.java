//Lucas Vance
//Core Java Homework
//Question 15
//Operands
package Q15;

public class OperandsClass implements OperandsInterface{

	@Override
	public int addition(int input1, int input2){
		return input1 + input2;
	}
	@Override
	public int subtraction(int input1, int input2){
		return input1 - input2;
	}
	@Override
	public int multiplication(int input1, int input2){
		return input1 * input2;
	}
	@Override
	public int division(int input1, int input2){
		return input1/input2;
	}

}
