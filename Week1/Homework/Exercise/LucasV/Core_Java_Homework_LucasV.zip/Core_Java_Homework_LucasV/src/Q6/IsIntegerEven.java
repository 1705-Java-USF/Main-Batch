//Lucas Vance
//Core Java Homework
//Question 6
//Is Integer Even
package Q6;

import java.util.Scanner;

public class IsIntegerEven {

	public static void main(String[] args) {
		//Instantiate IsIntegerEven object
		IsIntegerEven iie = new IsIntegerEven();
		//Create Scanner
		Scanner sc=new Scanner(System.in);		
		//Scan in next integer
		System.out.println("Enter an integer: ");
		int i = sc.nextInt();
		System.out.println(iie.isIntegerEven(i));
		//Close Scanner
		sc.close();
	}
	
	public boolean isIntegerEven(int input1) {
		//If the number is not divisible by 2, it will lose its 0.5
		int integerQuotient = input1 / 2; 
		//If the number lost its 0.5, it will not be equal to the original input when multiplied by 2
		return (integerQuotient * 2) == input1;
	}
}
