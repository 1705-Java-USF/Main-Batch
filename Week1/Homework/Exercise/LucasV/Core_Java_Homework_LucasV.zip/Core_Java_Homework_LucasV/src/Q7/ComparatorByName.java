package Q7;

import java.util.Comparator;

public class ComparatorByName implements Comparator<Employee>{

	@Override
	public int compare(Employee input1, Employee input2) {	
		return input1.getName().compareTo(input2.getName());
	}
}
