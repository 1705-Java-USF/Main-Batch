package Q7;

import java.util.Comparator;

public class ComparatorByDepartment implements Comparator<Employee> {

	@Override
	public int compare(Employee input1, Employee input2) {
		return input1.getDepartment().compareTo(input2.getDepartment());
	}
}
