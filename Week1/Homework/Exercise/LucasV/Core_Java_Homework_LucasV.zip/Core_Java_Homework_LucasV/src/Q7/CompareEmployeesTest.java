//Lucas Vance
//Core Java Homework
//Question 7
//Compare Employees
package Q7;

import java.util.ArrayList;
import java.util.Collections;

public class CompareEmployeesTest  {

	public static void main(String[] args) {
		
		//Create array list of type employee
		ArrayList<Employee> employees = new ArrayList<>();
		
		//Add new employees
		employees.add(new Employee("Bobbert", "Research", 19));
		employees.add(new Employee("Dogbert", "Marketing", 7));
		employees.add(new Employee("Lucas", "Software Engineering", 24));
		employees.add(new Employee("Bobbington IV", "Management", 48));
		
		//Sort employees by age
		Collections.sort(employees);
		System.out.println("Employees by age: " + employees);
		
		//Sort employees by name
		Collections.sort(employees, new ComparatorByName());
		System.out.println("Employees by name: " + employees);
		
		//Sort employees by department
		Collections.sort(employees, new ComparatorByDepartment());
		System.out.println("Employees by department:" + employees);
	}
}
