//Lucas Vance
//Core Java Homework
//Question 17
//Calculate Interest
package Q17;

import java.util.Scanner;

public class CalculateInterest {

	public static void main(String[] args) {
		//Prompt user for principal input double 
		Scanner s = new Scanner(System.in);
		System.out.print("Please enter a principal: ");
		double principal = s.nextDouble();
		System.out.println("Your principal is: " + principal + "$");
		//Prompt user for an interest rate input double
		System.out.print("Please enter an interest rate in percent: ");
		double rate = s.nextDouble();
		System.out.println("Your rate is : " + rate + "%");
		//Prompt user for a time duration in years (integer)
		System.out.print("Please enter a time duration: ");
		int time = s.nextInt();
		System.out.println("Your time duration is " + time + " years");
		//Call method to calculate interest and print
		double interest = calculator(principal, rate, time);
		System.out.println("Your interest is: " + interest);
		s.close();
	}
	
	//Create method to calculate and return interest
	public static double calculator(double principal, double rate, int time){
		double interest = principal*(rate/100)*time;		
		return interest;
	}
}
