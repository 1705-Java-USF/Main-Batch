//Lucas Vance
//Core Java Homework
//Question 2
//FibonacciNumbers
package Q2;

public class FibonacciNumbers {

	public static void main(String[] args) {
		//Set the value for first two numbers
		int x = 0;
		int y = 1;
		int z;
		int count = 23;
		
		//Print first two numbers
		System.out.print(x + " " + y);
		//Calculate and print remaining 23 numbers
		for(int i = 0; i < count; i++){
			z = y + x;
			x = y;
			y = z;
			System.out.print(" " + z);
		}

	}

}
