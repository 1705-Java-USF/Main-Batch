//Lucas Vance
//Core Java Homework
//Question 7
//Palindromes
package Q8;

import java.util.ArrayList;

import Q3.ReverseString;

public class PalindromesList {	
	//Create string array containing given words
	static final String[] strings = {
			"karan", 
			"madam", 
			"tom",
			"civic", 
			"radar", 
			"sexes", 
			"jimmy",
			"kayak", 
			"john",  
			"refer", 
			"billy",
			"did"
		};
	
	public static void main(String[] args) {
	//Create and store strings into array list
	ArrayList<String> al = new ArrayList<String>();
	for(int x = 0; x < strings.length; x++)
		al.add(strings[x]);

	//Create Palindromes ArrayList and call method to store palindromes
	ArrayList<String> pl = PalindromesList.palindromesList(al);
	System.out.println(pl);
	}

	
	//Method returns a palindromes arraylist and takes the original arraylist as arg
	public static ArrayList<String> palindromesList(ArrayList<String> al) {
		ArrayList<String> pl = new ArrayList<String>();
		//loop through input arraylist
		for(int i = 0; i < al.size(); i++){
			//check to see if each index is equal to its reverseString using q3's method
			if (al.get(i).equals(ReverseString.reverse(al.get(i)))){
				pl.add(al.get(i));
			}
		}
		return pl;
	}
	
	
}
