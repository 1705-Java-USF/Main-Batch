//Lucas Vance
//Core Java Homework
//Question 19
//Multiple Function Array List
package Q19;

import java.util.ArrayList;

import Q9.PrintPrimes;

public class MultiFunctionArrayList {

	public static void main(String[] args) {
		//Create an ArrayList
		ArrayList<Integer> al = new ArrayList<>();
		//Insert numbers 1 to 10 in Array List
		for(int i = 0; i < 10; i++){
			al.add(i+1);
		}
		//Display the Array List
		for(int x = 0; x < 10; x++)
			System.out.print(al.get(x) + " ");
		//Call returnEvensSum method and print sum of even numbers
		System.out.println("\n" + MultiFunctionArrayList.returnEvensSum(al));
		//Call returnOddsSum method and print sum of odd numbers
		System.out.println(MultiFunctionArrayList.returnOddsSum(al));
		//Create an ArrayList with primes removed
		ArrayList<Integer> noPrimes = new ArrayList<>();
		noPrimes = MultiFunctionArrayList.removePrimes(al);
		//Print out ArrayList with primes removed
		for(int y = 0; y < noPrimes.size(); y++){
			System.out.print(noPrimes.get(y) + " ");
		}
	}
	
	//Method to return sum of evens in input array list
	public static int returnEvensSum(ArrayList<Integer> al) {
		//Create sum of evens integer
		int evensSum = 0;
		//Loop through array list
		for(int i = 0; i < al.size(); i++){
			//Check if contents is divisible by 2
			if(al.get(i) % 2 == 0){
				//Add it to sum of evens integer
				evensSum += al.get(i);
			}
		}
		//Return sum of evens
		return evensSum;
	}
	
	//Method to return sum of odds in input array list
	public static int returnOddsSum(ArrayList<Integer> al) {
		//Create sum of odds integer
		int oddsSum = 0;
		//Loop through array list		
		for(int i = 0; i < al.size(); i++){
			//Check if contents is not divisible by 2			
			if(al.get(i) % 2 == 1){
				//Add it to sum of odds integer
				oddsSum += al.get(i);
			}
		}
		//Return sum of odds
		return oddsSum;
	}
	
	//Method to return an array list with primes removed
	public static ArrayList<Integer> removePrimes(ArrayList<Integer> al) {
		//Create the noPrimes array list
		ArrayList<Integer> noPrimes = new ArrayList<Integer>();
		//Loop through input array list
		for(int i = 0; i < al.size(); i++){
			//Call isPrime method from Q9
			if(!PrintPrimes.isPrime(al.get(i))){
				//If it wasn't prime, add it to noPrimes
				noPrimes.add(al.get(i));
			}
		}
		//Return noPrimes array list
		return noPrimes;
	}
}
