//Lucas Vance
//Core Java Homework
//Question 10
//Find Minimum
package Q10;

import java.util.Scanner;

public class MinimumNumber {

	public static void main(String[] args) {
		//Create Scanner
		Scanner sc=new Scanner(System.in);
		//Scan in two integers
		System.out.print("Enter an integer: ");
		int input1 = sc.nextInt();
		System.out.print("Enter another integer: ");
		int input2 = sc.nextInt();
		//Call the findMinimum method
		int min = MinimumNumber.findMinimum(input1, input2);
		System.out.println("The smallest number is: " + min);
		//Close scanner
		sc.close();
	}

	//Create method to take two input ints and return min
	public static int findMinimum(int input1, int input2){
		int min = (input1 < input2) ? input1 : input2;
		return min;
	}
}
