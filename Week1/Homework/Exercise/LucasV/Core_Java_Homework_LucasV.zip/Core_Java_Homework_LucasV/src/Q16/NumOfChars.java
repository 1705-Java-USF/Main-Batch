//Lucas Vance
//Core Java Homework
//Question 16
//Number of Characters in a String
package Q16;

public class NumOfChars {

	public static void main(String[] args) {
		//Create integer to count number of chars
		int count = 0;
		//Loop through args
		for(int i = 0; i < args[0].length(); i++) {
			//Save args to string
			String s = args[0];
			//Save char at index i
			char c = s.charAt(i);
			System.out.print(c + " ");
			//Increment count for each char
			count++;			
		}
		//Print to number of chars.
		System.out.println("\nNumber of characters: " + count);
	}
}
