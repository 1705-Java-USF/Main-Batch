package Q11_1;

public class GetFloats {
	//Create two private floats
	private final float f1 = 1.5F;
	private final float f2 = 2.5F;

	//Create two getter methods to get float values
	public float getF1() {
		return f1;
	}
	public float getF2() {
		return f2;
	}
	
}
