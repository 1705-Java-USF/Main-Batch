//Lucas Vance
//Core Java Homework
//Question 5
//Return Substring
package Q5;

import java.util.Scanner;

public class ReturnSubstring{
	static String STR = "This is my very special string";

	public static void main(String[] args) {
		//Print original string
		System.out.println("Original string: " + STR);
		//Create Scanner
		Scanner sc=new Scanner(System.in);
		//Scan in next integer
		System.out.print("Enter an integer: ");
		int idx = sc.nextInt();
		//Print substring of STR from index 0 to idx-1
		System.out.println(computeSubstring(STR, 0, idx));
		//Close Scanner
		sc.close();
	}
	
	public static String computeSubstring(String str, int startIndex, int endIndex) {
		//Create char array and put input string into the array
		char[] arrStr = str.toCharArray();
		//Create subStrArray
		char[] subStrArray = new char[endIndex];
		//copy chars to subStrArray from 0 to endIndex
		for (int i = startIndex;  i < endIndex; i++) {
			subStrArray[i] = arrStr[i];
		}
		//Convert subStrArray into String
		String subString = new String(subStrArray);
		//Return subString
		return subString;
	}
}
