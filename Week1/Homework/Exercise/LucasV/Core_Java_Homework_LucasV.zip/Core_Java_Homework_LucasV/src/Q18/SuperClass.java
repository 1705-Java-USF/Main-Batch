package Q18;

//Create abstract class with methods but no implementation
public abstract class SuperClass {
	public abstract boolean isUpper(String s1);
	public abstract String convertUpper(String s1);
	public abstract int convertStringToInt(String s1);
}