package Q18;

public class SubClass extends SuperClass{

	//Create method to determine if input contains upper case
	@Override
	public boolean isUpper(String input1) {
		//Save input to a local string s
		String s = input1;
		//Create char array and convert string s to char array
		char[] ch=s.toCharArray();  
		//Loop through array
		for(int x = 0; x < ch.length; x++){
			//Determine if each index contains an upper case to return true
			if (Character.isUpperCase(ch[x])){
				return true;
			}else{
				continue;
			}
		}
		//No upper case was found, return false
		return false;
	}

	//Create method to convert input to upper case
	@Override
	public String convertUpper(String input1) {
		//Create local string s and save input to it
		String s = input1;
		//Create another string to save upper case version of s
		String upperCase = s.toUpperCase();
		//Return upper case string
		return upperCase;
	}

	//Create method to convert input string to integer and add 10
	@Override
	public int convertStringToInt(String input1) {
		//Convert string to integer
		int i = Integer.parseInt(input1);
		//Add 10
		i += 10;
		//Return the integer
		return i;
	}

}
