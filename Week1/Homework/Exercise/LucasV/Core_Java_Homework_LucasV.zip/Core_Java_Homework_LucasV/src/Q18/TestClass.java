//Lucas Vance
//Core Java Homework
//Question 18
//Abstract Class and Implementations
package Q18;

import java.util.Scanner;

public class TestClass {
	public static void main(String[] args) {
		//Create child object to test method implementations
		SubClass s = new SubClass();
		//Create scanner
		Scanner sc=new Scanner(System.in);
		//Scan in string to check for upper case
		System.out.println("Please enter a string: ");
		String inputString = sc.nextLine();
		System.out.println(s.isUpper(inputString));
		//Scan in string to convert to upper case
		System.out.println("Please enter a string: ");
		String inputString2 = sc.nextLine();
		System.out.println(s.convertUpper(inputString2));
		//Scan in string to convert to integer and add 10
		System.out.println("Please enter a string: ");
		String inputString3 = sc.nextLine();
		System.out.println(s.convertStringToInt(inputString3));		
		//Close scanner
		sc.close();
	}
}
