//Lucas Vance
//Core Java Homework
//Question 4
//Compute Factorial
package Q4;

import java.util.Scanner;

public class ComputeFactorial {

	public static void main(String[] args) {
		//Create Scanner
		Scanner sc=new Scanner(System.in);
		//Scan in next integer
		System.out.println("Enter an integer: ");
		int input1 = sc.nextInt();
		//Print out factorial of integer
		if(input1 >= 0){
			try{
			System.out.println(ComputeFactorial.computeFactorial(input1));
			}catch(Exception e){
				e.printStackTrace();
			}			
		}else{
			System.out.println("Negative integers cannot be computed");
		}

		//Close scanner
		sc.close();
	}
	
	public static double computeFactorial(int input1) {
		if(input1 == 0){
			return 1;
		}
		//Calculate factorial
		return input1 == 1 ? 1 : input1 * computeFactorial(input1 - 1);
	}

}
