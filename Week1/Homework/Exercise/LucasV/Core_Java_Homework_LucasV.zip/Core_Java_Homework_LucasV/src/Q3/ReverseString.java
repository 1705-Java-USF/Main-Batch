//Lucas Vance
//Core Java Homework
//Question 3
//Reverse a String
package Q3;

public class ReverseString {
	//Set string value
	static String STR = "lucas vance";
	
	public static void main(String[] args) {
		//Print out original string
		System.out.println("Original string: " + STR);
		//Print out reversed string
		System.out.println("Reversed string: " + ReverseString.reverse(STR));
	}
	
	public static String reverse(String str) {
		//Check if string is null
		if (str.length() <= 1) {
		    return str;
		}
		//Return reverse string
		return str.charAt(str.length() - 1) + reverse(str.substring(0, str.length() - 1));
	}
}
