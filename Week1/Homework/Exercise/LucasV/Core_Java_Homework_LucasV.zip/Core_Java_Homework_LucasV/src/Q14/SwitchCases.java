//Lucas Vance
//Core Java Homework
//Question 14
//Switch Cases
package Q14;

import java.util.Date;
import java.util.Scanner;

public class SwitchCases {

	public static void main(String[] args) {
		//Create Scanner
		Scanner sc = new Scanner(System.in);
		//Scan in next integer
		System.out.print("Enter an integer 1, 2, or 3: ");
		int x = sc.nextInt();
		//Switch cases
		switch(x){
		case(1): 	//Prompt user for a double
					System.out.print("Please enter a number: ");
					double d = sc.nextDouble();
					//Print the square root by calling sqaureRoot method
					System.out.print("The Square Root of " + d + " is ");
					System.out.println(SwitchCases.squareRoot(d));
					break;
		case(2):	//Instantiate Date object
					Date date = new Date();
					//Print the date
	        		System.out.println("Today's date is: "+date.toString());
					break;
		case(3):	//Create string containing the specified sentence
					String s1 = "I am learning Core Java";
					//Split the string into an array using empty space as delimiter
					String[] parts = s1.split(" ");
					//Print out the split parts of the string array
					for(int i = 0; i < 5; i++)
						System.out.println(parts[i]);
					break;
		default: 	//Default case: user did not enter valid input
					System.out.println("Invalid input!");
		}
		//Close the scanner
		sc.close();
	}

	//Method to calculate sqaureRoot taking a double as input
	public static double squareRoot(double input1){
		//Make the calculation using Math.sqrt()
		double d = Math.sqrt(input1);
		//Return the result
		return d;
	}
	
}
