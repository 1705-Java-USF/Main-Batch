//Lucas Vance
//Core Java Homework
//Question 11
//Retrieve Floats
package Q11_2;

import Q11_1.GetFloats;

public class RetreiveFloats extends GetFloats{
	
	public static void main(String[] args) {
		//Create ReceiveFloats Object
		RetreiveFloats rf = new RetreiveFloats();
		//Call Parent's getter methods to get floats
		System.out.println(rf.getF1());
		System.out.println(rf.getF2());
	}
}
