//Lucas Vance
//Core Java Homework
//Question 9
//Print the Primes
package Q9;

import java.util.ArrayList;

public class PrintPrimes {

	public static void main(String[] args) {
		//Create array list of nums
		ArrayList<Integer> nums = new ArrayList<>();
		//Fill array list with nums from 1 to 100
		for(int x = 1; x <= 100; x++) {
			nums.add(x);
		}
		//loop through each num in array list
		for(int y = 0; y < nums.size(); y++){
			//check to see if num is prime using method
			if (PrintPrimes.isPrime(nums.get(y))){
				//print out prime nums
				System.out.print(nums.get(y) + " ");
			}
		}
		
	}

	public static boolean isPrime(int num){
		//Prime numbers must be greater than 1
		if(num == 1){
			return false;
		}
		//Check to see if num is divisible by any numbers greater than 1
		for (int x = 2; (x * 2) < num; x++) {
			//Return false if number was divisible by a num
			if (num % x == 0) {
	         	return false;
	        }         
		}
		//No divisor was found, return true
		return true;
	}
}
