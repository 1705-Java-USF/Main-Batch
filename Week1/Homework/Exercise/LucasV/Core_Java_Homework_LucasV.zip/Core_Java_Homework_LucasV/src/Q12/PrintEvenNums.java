//Lucas Vance
//Core Java Homework
//Question 12
//Print Evens
package Q12;

public class PrintEvenNums {
	public static void main(String[] args) {
		//Create array of size 100
		int[] nums = new int[100];
		//Store numbers 1 to 100
		for(int i = 0; i < 100; i ++){
			nums[i]= i+1;
		}
		//Loop through nums array using enhanced loop
		for(int x : nums){
			//Print only the even numbers 
			if (x % 2 == 0)
				System.out.print(x + " ");
		}
	}
}
