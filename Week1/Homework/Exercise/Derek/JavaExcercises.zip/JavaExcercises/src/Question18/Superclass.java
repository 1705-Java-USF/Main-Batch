package Question18;

//Abstract Superclass providing three abstract method declarations.
//One of type boolean, String, and int with String parameters.
public abstract class Superclass {
	
	public abstract boolean methodB(String s1);
	
	public abstract String methodS(String s1);
	
	public abstract int methodI(String s1);
}
