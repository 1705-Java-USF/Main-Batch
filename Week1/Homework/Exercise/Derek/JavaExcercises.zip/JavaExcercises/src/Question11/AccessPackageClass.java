package Question11;

public class AccessPackageClass {

	//Class that holds two float variables
	public float num1 = 5f;
	public float num2 = 4f;
	
	//Getter functions to retrieve the float values of num1 & num2
	public float getNum1() {
		return num1;
	}
	
	public float getNum2() {
		return num2;
	}
}
