function fizz() {

	var min = parseInt(document.getElementById("min").value);
	var max = parseInt(document.getElementById("max").value);
	var x = document.getElementById('invalid');
	var r = document.getElementById("results");
	var fizzbuzz = "fizzbuzz";
	var buzz = "buzz";
	var fizz = "fizz";
	var nl = "<br>"

	
	if (min > max) {
		x.innerHTML = "invalid";
	} else {
		x.style.display = 'none';
	}
		if (r.innerHTML != ""){
		r.innerHTML = "";
	}

	for (var i = min; i <= max; i++) {

		if (i % 3 == 0 && i % 5 == 0) {
			r.innerHTML += fizzbuzz;
		}

		else if (i % 3 == 0) {
			r.innerHTML += fizz;
		}

		else if (i % 5 == 0) {
			r.innerHTML += buzz;
		} else {
			r.innerHTML += i;
		}
		r.innerHTML += nl;

	}

}