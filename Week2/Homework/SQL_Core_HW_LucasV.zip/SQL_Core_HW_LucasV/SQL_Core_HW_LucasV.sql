--2.1
--Task � Select all records from the Employee table.
Select * FROM Employee;
--Task � Select all records from the Employee table where last name is King.
Select * FROM Employee
where LASTNAME = 'King';
--Task � Select all records from the Employee table where first name is Andrew and REPORTSTO is NULL.
Select * FROM Employee
where FIRSTNAME = 'Andrew'
and REPORTSTO is null;

--2.2 ORDER BY
--Task � Select all albums in Album table and sort result set in descending order by title.
Select * FROM ALBUM
order by TITLE desc;
--Task � Select first name from Customer and sort result set in ascending order by city
Select FIRSTNAME from CUSTOMER
order by CITY;

--2.3 INSERT INTO
--Task � Insert two new records into Genre table
INSERT INTO GENRE
VALUES (26, 'Trance');
INSERT INTO GENRE
VALUES (27, 'ChillStep');
--Task � Insert two new records into Employee table
INSERT INTO EMPLOYEE
VALUES (9, 'Bobbington', 'Bobberto', 'IT Staff', 6, '01-JAN-91', '15-JAN-12', '1234 Main ST', 'Dover', 'MD', 'USA', '19722', '+1 (303) 555-9999', '+1 (303) 555-1111', 'bobberto@chinookcorp.com');
INSERT INTO EMPLOYEE
VALUES (10, 'Cattington', 'Dogberto', 'Sales Support Agent', 2, '06-FEB-60', '21-FEB-10', '5541 Broadway Ave', 'Denville', 'NJ', 'USA', '07041', '+1 (973) 333-9999', '+1 (973) 777-1111', 'dogberto@chinookcorp.com');
--Task � Insert two new records into Customer table
INSERT INTO CUSTOMER
VALUES (60, 'Sandy', 'Sandableness', null, '812 5th Ave', 'New York', 'NY', 'USA', '10070', '+1 (212) 555-5522', '+1 (212) 555-5500', 'ssandableness@yahoo.com', 3);
INSERT INTO CUSTOMER
VALUES (61, 'Rudolph', 'Reindolpher', null, '215 48th Street', 'New York', 'NY', 'USA', '10070', '+1 (212) 333-1122', '+1 (212) 333-1100', 'rreindolpher@gmail.com', 5);

--2.4 UPDATE
--Task � Update Aaron Mitchell in Customer table to Robert Walter
UPDATE CUSTOMER
SET FIRSTNAME = 'Robert',
LASTNAME = 'Walter'
WHERE lower(FIRSTNAME) = lower('Aaron')
AND lower(LASTNAME) = lower('Mitchell');
--Task � Update name of artist in the Artist table �Creedence Clearwater Revival� to �CCR�
UPDATE ARTIST
SET NAME = 'CCR'
WHERE lower(NAME) = lower('Creedence Clearwater Revival');

--2.5 LIKE
--Task � Select all invoices with a billing address like �T%�
select * from INVOICE
where BILLINGADDRESS like 'T%';

--2.6 BETWEEN
--Task � Select all invoices that have a total between 15 and 50
SELECT * FROM INVOICE
WHERE TOTAL BETWEEN 15 AND 50;
--Task � Select all employees hired between 1st of June 2003 and 1st of March 2004
SELECT * FROM EMPLOYEE
WHERE HIREDATE BETWEEN '01-JUN-03' AND '01-MAR-04';

--2.7 DELETE
--Task � Delete a record in Customer table where the name is Robert Walter (There may be constraints that rely on this, find out how to resolve them).
DELETE FROM INVOICELINE
WHERE INVOICEID IN
(SELECT INVOICEID FROM INVOICE
WHERE CUSTOMERID = (SELECT CUSTOMERID FROM CUSTOMER
WHERE FIRSTNAME = 'Robert' AND LASTNAME = 'Walter'));

DELETE FROM INVOICE
WHERE CUSTOMERID = (SELECT CUSTOMERID FROM CUSTOMER
WHERE FIRSTNAME = 'Robert' AND LASTNAME = 'Walter');

DELETE FROM CUSTOMER
WHERE FIRSTNAME = 'Robert' AND LASTNAME = 'Walter';

--3.1 System Defined Functions
--Task � Create a function that returns the current time.
alter session set nls_date_format='DD-MON-YYYY HH:MI:SS';

create or replace function getSysdate
return date is
  l_sysdate Date;
begin
select current_date
    into l_sysdate
    from dual;
  return l_sysdate;
end;

select getSysdate() from dual;

--Task � create a function that returns the length of a mediatype from the mediatype table
CREATE or REPLACE FUNCTION get_mediaTypeLength(a_mediaTypeID IN NUMBER) 
   RETURN NUMBER 
   IS returnLength NUMBER(11,2);
   BEGIN
      SELECT LENGTH(NAME) "String length in characters"
      INTO returnLength 
      FROM MediaType 
      WHERE MEDIATYPEID = a_mediaTypeID; 
      RETURN(returnLength ); 
    END;

select get_mediaTypeLength(3) from dual;

--3.2 System Defined Aggregate Functions
--Task � Create a function that returns the average total of all invoices
CREATE or REPLACE FUNCTION returnAVG
    RETURN NUMBER
    IS returnAVG NUMBER(11,3);
    BEGIN
    SELECT AVG(TOTAL)
    into returnAVG
    FROM INVOICE;
    RETURN returnAVG;
END;

select returnAVG from dual;

--Task � Create a function that returns the most expensive track
CREATE or REPLACE FUNCTION returnMaxUnitPrice
    RETURN NUMBER
    IS returnMax NUMBER(11,3);
    BEGIN
    SELECT MAX(UNITPRICE)
    into returnMAX
    FROM TRACK;
    RETURN returnMax;
END;

select returnMaxUnitPrice from dual;

--3.3 User Defined Scalar Functions
--Task � Create a function that returns the average price of invoiceline items in the invoiceline table
CREATE or REPLACE FUNCTION returnAvgPrice
    RETURN NUMBER
    IS returnAvgPrice NUMBER(11,3);
    BEGIN
    SELECT AVG(UNITPRICE)
    into returnAvgPrice
    FROM INVOICELINE;
    RETURN returnAvgPrice;
END;

select returnAvgPrice from dual;

--3.4 User Defined Table Valued Functions
--Task � Create a function that returns all employees who are born after 1968.\
CREATE TABLE EMPLOYEEID
(
EMPLOYEEID      NUMBER(9) NOT NULL,
BIRTHDATE    DATE,
PRIMARY KEY(EMPLOYEEID)
)

INSERT INTO EMPLOYEEID(EMPLOYEEID, BIRTHDATE)
SELECT EMPLOYEEID, BIRTHDATE
FROM EMPLOYEE
WHERE BIRTHDATE > '31-DEC-1968';

CREATE OR REPLACE TYPE EMPLOYEE_OBJ_TYPE IS OBJECT
(
EMPLOYEEID   NUMBER(9),
BIRTHDATE DATE
);

CREATE OR REPLACE TYPE EMPLOYEE_TABTYPE AS TABLE OF EMPLOYEE_OBJ_TYPE;

CREATE OR REPLACE FUNCTION FN_GET_ROWS
RETURN EMPLOYEE_TABTYPE
AS
V_EMPLOYEE_Tabtype EMPLOYEE_TabType;
BEGIN
SELECT EMPLOYEE_OBJ_TYPE(A.EMPLOYEEID, A.BIRTHDATE)
BULK COLLECT INTO V_EMPLOYEE_TabType
FROM
(SELECT EMPLOYEEID, BIRTHDATE
FROM EMPLOYEE
WHERE BIRTHDATE > '31-DEC-1968') A;
RETURN V_EMPLOYEE_TabType;

EXCEPTION
WHEN OTHERS THEN
v_EMPLOYEE_TabType.DELETE;
RETURN v_EMPLOYEE_TabType;
END;

SELECT FN_GET_ROWS FROM DUAL;

--4.0 Stored Procedures
--In this section you will be creating and executing stored procedures.
--You will be creating various types of stored procedures that take input and output parameters.
--4.1 Basic Stored Procedure
--Task � Create a stored procedure that selects the first and last names of all the employees.
CREATE OR REPLACE PROCEDURE returnFirstLastNames
IS
   TYPE employee_aat 
   IS TABLE OF employee%ROWTYPE
      INDEX BY PLS_INTEGER;
   l_employee employee_aat;
BEGIN
   SELECT *
   BULK COLLECT INTO l_employee
      FROM employee;
     
   FOR indx IN 1 .. l_employee.COUNT 
   LOOP
       DBMS_OUTPUT.PUT_LINE 
      (l_employee (indx).FIRSTNAME || ', ' || l_employee (indx).LASTNAME);
   END LOOP;
END;

begin
   returnFirstLastNames();
end;

--4.2 Stored Procedure Input Parameters
--Task � Create a stored procedure that updates the personal information of an employee.
CREATE OR REPLACE PROCEDURE updatePersonalInfo(
	   P_EMPLOYEEID IN EMPLOYEE.EMPLOYEEID%TYPE,
	   P_FIRSTNAME IN EMPLOYEE.FIRSTNAME%TYPE)
IS
BEGIN
  UPDATE EMPLOYEE SET FIRSTNAME = P_FIRSTNAME where EMPLOYEEID = P_EMPLOYEEID;
  COMMIT;
END;

BEGIN
   updatePersonalInfo(1,'Andrew');
END;

--Task � Create a stored procedure that returns the managers of an employee.
CREATE OR REPLACE PROCEDURE returnManagers(a_employeeid in employee.employeeid%type, a_firstname out employee.firstname%type, a_lastname out employee.lastname%type)
IS
BEGIN
    select FIRSTNAME,LASTNAME
    into a_firstname, a_lastname
    from employee
    where employeeid = 
    (select REPORTSTO from employee
    where employeeid = a_employeeid);
    DBMS_OUTPUT.PUT_LINE(a_firstname || a_lastname);
END;

DECLARE
    a_firstname employee.firstname%type;
    a_lastname employee.lastname%type;  
BEGIN
   returnManagers(3, a_firstname, a_lastname);
END;

--4.3 Stored Procedure Output Parameters
--Task � Create a stored procedure that returns the name and company of a customer.
select * from customer;

CREATE OR REPLACE PROCEDURE returnNameCompany(a_customerid in customer.customerid%type, a_firstname out customer.firstname%type, a_lastname out customer.lastname%type, a_company out customer.company%type)
IS
BEGIN
    SELECT FIRSTNAME, LASTNAME, COMPANY
    INTO a_firstname, a_lastname, a_company
    FROM CUSTOMER
    WHERE customerid = a_customerid;
    DBMS_OUTPUT.PUT_LINE(a_firstname || ' ' || a_lastname || ' ' || a_company);
END;

DECLARE
    a_firstname customer.firstname%type;
    a_lastname customer.lastname%type;
    a_company customer.company%type;
BEGIN
   returnNameCompany(1, a_firstname, a_lastname, a_company);
END;

--5.0 Transactions
--In this section you will be working with transactions. Transactions are usually nested within a stored procedure.
--Task � Create a transaction that given a invoiceId will delete that invoice (There may be constraints that rely on this, find out how to resolve them).
ALTER TABLE INVOICELINE DROP CONSTRAINT FK_INVOICELINEINVOICEID;
ALTER TABLE INVOICELINE ADD CONSTRAINT FK_INVOICELINEINVOICEID 
FOREIGN KEY (INVOICEID) REFERENCES INVOICE (INVOICEID) ON DELETE CASCADE;

CREATE OR REPLACE PROCEDURE deleteInvoiceByID (a_invoiceid in invoice.invoiceid%type)
IS
BEGIN
    
    DELETE FROM INVOICE CASCADE WHERE INVOICEID = a_invoiceid;
    COMMIT;
END;

BEGIN
   deleteInvoiceByID(323);
END;

--Task � Create a transaction nested within a stored procedure that inserts a new record in the Customer table
select * from customer;

CREATE OR REPLACE PROCEDURE insertIntoCustomer(
a_customerid in customer.customerid%type,
a_firstname in customer.firstname%type,
a_lastname in customer.lastname%type,
a_company in customer.company%type,
a_address in customer.address%type,
a_city in customer.city%type,
a_state in customer.state%type,
a_country in customer.country%type,
a_postalcode in customer.postalcode%type,
a_phone in customer.phone%type,
a_fax in customer.fax%type,
a_email in customer.email%type,
a_supportrepid in customer.supportrepid%type)
IS
BEGIN
    INSERT INTO CUSTOMER
    VALUES (a_customerid,
    a_firstname,
    a_firstname,
    a_company,
    a_address,
    a_city,
    a_state,
    a_country,
    a_postalcode,
    a_phone,
    a_fax,
    a_email,
    a_supportrepid);
    COMMIT;
END;

BEGIN
   insertIntoCustomer(
   62,
   'Sunny',
   'Suntastic',
   null,
   '4415 35th Street',
   'New York',
   'NY',
   'USA',
   '10070',
   '+1 (212) 541-1451',
   '+1 (212) 541-2452',
   'ssuntastic@msn.com',
   5);
END;

--6.0 Triggers
--In this section you will create various kinds of triggers that work when certain DML statements are executed on a table.
--6.1 AFTER/FOR
--Task - Create an after insert trigger on the employee table fired after a new record is inserted into the table.
CREATE OR REPLACE TRIGGER employeeInsertTrigger
AFTER INSERT ON EMPLOYEE
FOR EACH ROW
BEGIN
  DBMS_OUTPUT.PUT_LINE('New Record Inserted Into Employee!!!');
END;

--Task � Create an after update trigger on the album table that fires after a row is inserted in the table
CREATE OR REPLACE TRIGGER updateAlbumTrigger
AFTER UPDATE ON ALBUM
FOR EACH ROW
BEGIN
  DBMS_OUTPUT.PUT_LINE('A Row Has Been Updated!!!');
END;

--Task � Create an after delete trigger on the customer table that fires after a row is deleted from the table.
CREATE OR REPLACE TRIGGER deleteCustomerRowTrigger
AFTER DELETE ON CUSTOMER
FOR EACH ROW
BEGIN
  DBMS_OUTPUT.PUT_LINE('A Row Has Been Deleted!!!');
END;

--7.0 JOINS
--In this section you will be working with combing various tables through the use of joins. You will work with outer, inner, right, left, cross, and self joins.
--7.1 INNER
--Task � Create an inner join that joins customers and orders and specifies the name of the customer and the invoiceId.
select * from (select a.firstname, a.lastname, b.invoiceid from customer a
 inner join invoice b
 on a.customerid = b.customerid);

--7.2 OUTER
--Task � Create an outer join that joins the customer and invoice table, specifying the CustomerId, firstname, lastname, invoiceId, and total.
select * from (select a.customerid, a.firstname, a.lastname, b.invoiceid, b.total from customer a
 full outer join invoice b
 on a.customerid = b.customerid);

--7.3 RIGHT
--Task � Create a right join that joins album and artist specifying artist name and title.
select * from (select a.name, b.title from artist a
 right join album b
 on a.artistid = b.artistid);

--7.4 CROSS
--Task � Create a cross join that joins album and artist and sorts by artist name in ascending order.
select * from (select a.name from artist a
 cross join album b
 order by a.name);

--7.5 SELF
--Task � Perform a self-join on the employee table, joining on the reports to column.
select * from employee a
inner join employee b
on a.REPORTSTO = b.reportsto;

--
commit;

