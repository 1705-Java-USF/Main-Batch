package com.bank;

import static org.junit.Assert.assertTrue;

import java.io.File;

import org.junit.Test;

public class BankAccountTester {

	//Test if the file that BankAccountIO is reading from exists in the directory.
	@Test
	public void checkFileExist() {
		File file = new File("NewAccInfo.txt");
		assertTrue(file.exists());
	}

}
