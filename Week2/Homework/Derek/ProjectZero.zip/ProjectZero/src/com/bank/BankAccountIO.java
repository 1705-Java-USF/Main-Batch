package com.bank;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;


public class BankAccountIO {
	
	final static Logger logger = Logger.getLogger(BankAccountIO.class);
	FileWriter file;
	BufferedWriter outWrite;

	public static void main(String[] args) throws IOException {
		
		//User directory location and text files
		String s1 = System.getProperty("user.dir");
	    String readPath = s1 + "\\BankAccInfo.txt";
	    String writePath = s1 + "\\NewAccInfo.txt";
	    BasicConfigurator.configure();
	    
	    
	    //Read and write
	    BankAccountIO bank = new BankAccountIO();
		bank.read(readPath);
		bank.write(writePath);

	}
	
	public void write(String FilePath) throws IOException {
		
		try {
		
			file = new FileWriter(FilePath, true);
			outWrite = new BufferedWriter(file);
			Scanner input = new Scanner(System.in);
			List<BankAccount> account = new ArrayList<BankAccount>();
			int id = 0;
			String name = " ";
			double balance = 0.0;
			boolean done = false;
			int answer = 0;
			
			//3 default bank accounts
			BankAccount a1 = new BankAccount(1, "Bobbert", 238.5);
			BankAccount a2 = new BankAccount(2, "Randy", 89.1);
			BankAccount a3 = new BankAccount(3, "Zane", 427.3);
			
			/*
			 * User input for making bank accounts in a do while loop as long as done is false.
			 * Pressing 1 finishes, and pressing 0 allows more inputs of bank accounts.
			 */
			do {
				System.out.println("Please enter an ID number: ");
				id = input.nextInt();
				System.out.println("Please enter a first name: ");
				name = input.next();
				System.out.println("Please enter an account balance: ");
				balance = input.nextDouble();
				
				//Add user inputs to ArrayList
				account.add(new BankAccount(id, name, balance));
				System.out.println("Are you done? Press 1 for yes and press 0 for no: ");
				answer = input.nextInt();
				
				if(answer == 1) {
					done = true;
					input.close();
					break;
				}
				else if(answer == 0) {
					done = false;
				}
				
			}while(done == false);
			
			//Add the default bank accounts to the collection list.
			account.add(a1);
			account.add(a2);
			account.add(a3);
			
			//Print out accounts in proper format with toString().
			for(int i = 0; i < account.size(); i++) {
				outWrite.write(account.get(i).toString() + "\n");
			}
			outWrite.close();
		}
		catch(IOException ex) {
			System.out.println("Error writing to file " + FilePath);
		}
	}
	
	public void read(String FilePath) throws IOException {
		
		FileReader fr = new FileReader(FilePath);
		BufferedReader br = new BufferedReader(fr);
		
		try {
			
			String line;
			int i = 0;
			
			//Log each line to console, reading from the file by line
			while((line = br.readLine()) != null) {
				
				logger.info(line + "\n");
			}
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		finally {
			if(br != null) {
				br.close();
			}
		}
	}

}
