package com.bank;

public class BankAccount {
	
	//3 key variables to use for BankAccount
	private int bankAccountNumber;
	private String customerName;
	private double balance;
	
	//Constructor
	public BankAccount(int bankAccountNumber, String customerName, double balance) {
		
		super();
		this.setBankAccountNumber(bankAccountNumber);
		this.setCustomerName(customerName);
		this.setBalance(balance);
	}
	
	/*
	 * Getters and setters for account number, name, and balance.
	 * toString method for being able to print out the ArrayList of objects effectively.
	 */
	public int getBankAccountNumber() {
		return bankAccountNumber;
	}
	
	public void setBankAccountNumber(int bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}
	
	public String getCustomerName() {
		return customerName;
	}
	
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	public double getBalance() {
		return balance;
	}
	
	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Bank account number = " + bankAccountNumber + ", Customer name = " + customerName + ", Balance = "
				+ balance;
	}
	
}
